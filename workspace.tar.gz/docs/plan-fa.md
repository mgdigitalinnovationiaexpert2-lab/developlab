# Formobile / FormEngine — نقشهٔ فنی (FastAPI + React/Vite + SQLite)

این سند نسخهٔ به‌روزشدهٔ نقشه است، منطبق با استک اعلام‌شدهٔ شما.
کد اجرایی همین نقشه در پوشهٔ `FormEngine/` است؛ راهنمای اجرا `FormEngine/README-fa.md`
و راهنمای نشانده‌کردن روی ساختار موجود `FormEngine/MERGE-fa.md`.

---

## ۱) مدل جداسازی — «خصوصی per کاربر، قابل اشتراک‌گذاری»

```
Tenant (فضای کاری)
 └─ User (عضو؛ نقش: owner | admin | editor | viewer)
     └─ PathNode (مسیر؛ owner_id دارد، درختی با parent_id)
         ├─ PathPermission (چه عضوی، چه اجازه‌ای: read | write | manage)
         ├─ Form → FormVersion (schema_json نسخه‌دار)
         │    └─ Submission (به نسخهٔ زمان ثبت گره خورده)
         └─ StoredFile (کلید ذخیره‌سازی تولیدشده)
```

قواعد اجراشده در `app/core/permissions.py`:

1. `path.tenant_id != user.tenant_id` ⇒ هیچ دسترسی‌ای (حتی با شناسهٔ درست).
2. مالک مسیر ⇒ `manage`.
3. مجوز از زنجیرهٔ پدرها ارث می‌رسد؛ بالاترین سطح برنده است.
4. `visibility='tenant'` ⇒ همهٔ اعضای همان فضا `read`.
5. مدیر پیش‌فرض مسیرهای خصوصی دیگران را نمی‌بیند؛ با
   `Tenant.admin_can_view_private_paths=True` فقط `read` می‌گیرد.
6. منبع غیرمجاز ⇒ **404** (نه 403).

## ۲) احراز هویت

| موضوع | پیاده‌سازی |
|---|---|
| هش رمز | Argon2id (`argon2-cffi`)، rehash خودکار |
| نشست | JWT در کوکی `HttpOnly` + رکورد `user_sessions` برای ابطال فوری |
| قفل حساب | ۵ تلاش ناموفق ⇒ ۱۵ دقیقه (`FM_LOCKOUT_*`) |
| عضوگیری | فقط مدیر: دعوت‌نامهٔ یک‌بارمصرف ۷۲ ساعته یا ساخت مستقیم با رمز موقت |
| ثبت‌نام عمومی | وجود ندارد |
| تغییر رمز | ابطال همهٔ نشست‌های دیگر |
| غیرفعال‌سازی | ابطال نشست + انتقال مالکیت مسیر/فرم به مدیر |
| گزارش | `audit_logs` برای همهٔ رویدادهای مهم |

## ۳) فرم‌ساز

- schema در `form_versions.schema_json`؛ هر تغییر معنادار ⇒ نسخهٔ جدید
- انواع فیلد: text, textarea, number, email, mobile, **national_id**, **date_jalali**,
  select, radio, checkbox, file, signature, heading, page_break
- اعتبارسنجی سروری در `app/services/form_schema.py` (الزامی، طول، بازه، الگو، یکتایی، گزینه‌های مجاز،
  الگوریتم کد ملی، تاریخ شمسی، تبدیل ارقام فارسی/عربی)
- نمایش شرطی با `visible_when`
- انتشار عمومی: `/f/{tenant_slug}/{form_slug}` فقط برای فرم `published` + `public_enabled`
- خروجی CSV با BOM برای Excel فارسی

## ۴) فایل‌ها

- ذخیره: `storage/{tenant_id}/{path_id}/{uuid}.bin` — نام کاربر فقط در دیتابیس
- پوشهٔ storage هرگز static-mount نمی‌شود
- دانلود: بررسی ACL لحظه‌ای یا لینک HMAC با انقضای ۶۰ ثانیه (`FM_DOWNLOAD_LINK_SECONDS`)
- آپلود: لیست سفید پسوند، سقف حجم جریانی، SHA-256، `Content-Disposition: attachment` + `nosniff`

## ۵) تست‌های ضدنشت (IDOR)

`backend/tests/test_isolation.py` — ۱۵ تست:
مسیر خصوصی عضو دیگر، شناسهٔ مستقیم از فضای کاری دیگر، ارث‌بری و لغو اشتراک،
نقش بیننده نتواند فرم بسازد، فرم/پاسخ/فایل کاربر دیگر 404، لینک امضاشدهٔ دستکاری‌شده 404،
پسوند غیرمجاز 415، قفل حساب، ابطال نشست، نسخه‌بندی فرم، اعتبارسنجی کد ملی/موبایل.

## ۶) قدم‌های بعدی

1. ادغام با پروژهٔ اصلی (نیازمند zip/درخت پوشه‌ها)
2. Alembic برای Migration (الان `create_all`)
3. SMTP برای دعوت‌نامه + فراموشی رمز
4. TOTP برای مدیر
5. Rate limit + CAPTCHA روی مسیرهای عمومی
6. پشتیبان‌گیری `VACUUM INTO` + پوشهٔ storage
7. سخت‌سازی تولید: HTTPS، `FM_COOKIE_SECURE=1`، HSTS/CSP، لاگ چرخشی
