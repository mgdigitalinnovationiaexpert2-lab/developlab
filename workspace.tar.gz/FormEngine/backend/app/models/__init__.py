"""مدل‌های داده.

قاعدهٔ طلایی جداسازی: هر جدولی که دادهٔ کاربر دارد ستون tenant_id دارد و
هر مسیر (PathNode) یک owner_id دارد. کوئری‌ها همیشه با این دو فیلتر می‌شوند.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, Index,
)
from sqlalchemy.orm import relationship

from app.db.session import Base


def uid() -> str:
    return uuid.uuid4().hex


def now() -> datetime:
    return datetime.utcnow()


class Tenant(Base):
    __tablename__ = "tenants"
    id = Column(String(32), primary_key=True, default=uid)
    name = Column(String(120), nullable=False)
    slug = Column(String(60), nullable=False, unique=True, index=True)
    is_active = Column(Boolean, default=True, nullable=False)
    admin_can_view_private_paths = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=now)


class User(Base):
    __tablename__ = "users"
    __table_args__ = (UniqueConstraint("tenant_id", "username", name="uq_user_tenant_username"),)
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    username = Column(String(60), nullable=False)
    email = Column(String(160), nullable=True)
    full_name = Column(String(120), nullable=False, default="")
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="editor")  # owner | admin | editor | viewer
    is_active = Column(Boolean, default=True, nullable=False)
    must_change_password = Column(Boolean, default=False, nullable=False)
    failed_count = Column(Integer, default=0, nullable=False)
    lockout_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)
    last_login_at = Column(DateTime, nullable=True)

    tenant = relationship("Tenant")


class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(String(32), primary_key=True, default=uid)
    user_id = Column(String(32), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime, default=now)
    expires_at = Column(DateTime, nullable=False)
    revoked_at = Column(DateTime, nullable=True)
    ip = Column(String(60), nullable=True)


class Invite(Base):
    __tablename__ = "invites"
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    username = Column(String(60), nullable=False)
    email = Column(String(160), nullable=True)
    full_name = Column(String(120), default="")
    role = Column(String(20), default="editor")
    token_hash = Column(String(64), nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    used_at = Column(DateTime, nullable=True)
    created_by = Column(String(32), nullable=True)
    created_at = Column(DateTime, default=now)


class PathNode(Base):
    """«مسیر» = پوشهٔ درختی متعلق به یک کاربر داخل یک فضای کاری."""
    __tablename__ = "paths"
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    owner_id = Column(String(32), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    parent_id = Column(String(32), ForeignKey("paths.id", ondelete="CASCADE"), nullable=True, index=True)
    name = Column(String(120), nullable=False)
    slug = Column(String(120), nullable=False)
    visibility = Column(String(20), default="private", nullable=False)  # private | shared | tenant
    created_at = Column(DateTime, default=now)


class PathPermission(Base):
    __tablename__ = "path_permissions"
    __table_args__ = (UniqueConstraint("path_id", "user_id", name="uq_path_user"),)
    id = Column(String(32), primary_key=True, default=uid)
    path_id = Column(String(32), ForeignKey("paths.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(32), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    permission = Column(String(20), nullable=False, default="read")  # read | write | manage
    created_at = Column(DateTime, default=now)


class Form(Base):
    __tablename__ = "forms"
    __table_args__ = (UniqueConstraint("tenant_id", "slug", name="uq_form_tenant_slug"),)
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    path_id = Column(String(32), ForeignKey("paths.id", ondelete="CASCADE"), nullable=False, index=True)
    owner_id = Column(String(32), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(200), nullable=False)
    slug = Column(String(120), nullable=False)
    description = Column(Text, default="")
    status = Column(String(20), default="draft", nullable=False)  # draft | published | closed
    public_enabled = Column(Boolean, default=False, nullable=False)
    require_login = Column(Boolean, default=False, nullable=False)
    one_per_user = Column(Boolean, default=False, nullable=False)
    current_version = Column(Integer, default=1, nullable=False)
    created_at = Column(DateTime, default=now)
    updated_at = Column(DateTime, default=now, onupdate=now)


class FormVersion(Base):
    __tablename__ = "form_versions"
    __table_args__ = (UniqueConstraint("form_id", "version_no", name="uq_form_version"),)
    id = Column(String(32), primary_key=True, default=uid)
    form_id = Column(String(32), ForeignKey("forms.id", ondelete="CASCADE"), nullable=False, index=True)
    version_no = Column(Integer, nullable=False, default=1)
    schema_json = Column(Text, nullable=False, default='{"fields":[]}')
    created_at = Column(DateTime, default=now)
    created_by = Column(String(32), nullable=True)


class Submission(Base):
    __tablename__ = "submissions"
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    path_id = Column(String(32), ForeignKey("paths.id", ondelete="CASCADE"), nullable=False, index=True)
    form_id = Column(String(32), ForeignKey("forms.id", ondelete="CASCADE"), nullable=False, index=True)
    form_version_id = Column(String(32), nullable=False)
    data_json = Column(Text, nullable=False, default="{}")
    submitted_by = Column(String(32), nullable=True)
    ip = Column(String(60), nullable=True)
    created_at = Column(DateTime, default=now)
    deleted_at = Column(DateTime, nullable=True)


Index("ix_sub_form_created", Submission.form_id, Submission.created_at)


class StoredFile(Base):
    __tablename__ = "files"
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    path_id = Column(String(32), ForeignKey("paths.id", ondelete="CASCADE"), nullable=False, index=True)
    form_id = Column(String(32), nullable=True, index=True)
    submission_id = Column(String(32), nullable=True, index=True)
    storage_key = Column(String(300), nullable=False)      # نام تولیدشده، نه نام کاربر
    original_name = Column(String(255), nullable=False)
    content_type = Column(String(120), default="application/octet-stream")
    size = Column(Integer, default=0)
    sha256 = Column(String(64), default="")
    uploaded_by = Column(String(32), nullable=True)
    created_at = Column(DateTime, default=now)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(String(32), primary_key=True, default=uid)
    tenant_id = Column(String(32), nullable=True, index=True)
    user_id = Column(String(32), nullable=True)
    action = Column(String(60), nullable=False)
    entity_type = Column(String(40), default="")
    entity_id = Column(String(32), default="")
    ip = Column(String(60), default="")
    meta_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=now, index=True)
