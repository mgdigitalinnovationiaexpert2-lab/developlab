from fastapi import APIRouter

from app.api.v1 import audit, auth, files, forms, paths, public, submissions, users

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(paths.router)
api_router.include_router(forms.router)
api_router.include_router(submissions.router)
api_router.include_router(files.router)
api_router.include_router(audit.router)
api_router.include_router(public.router)
