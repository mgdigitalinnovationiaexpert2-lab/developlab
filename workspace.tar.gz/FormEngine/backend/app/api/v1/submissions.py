"""پاسخ‌های فرم: فهرست، مشاهده، حذف نرم، خروجی CSV و ثبت پاسخ توسط عضو."""
from __future__ import annotations

import csv
import io
import json

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import client_ip, get_current_user
from app.core.guards import current_version, get_form_or_404, get_submission_or_404
from app.core.security import utcnow
from app.db.session import get_db
from app.models import Submission, User
from app.schemas import SubmitIn, submission_dto
from app.services.audit import log
from app.services.submissions import create_submission

router = APIRouter(tags=["submissions"])


@router.get("/forms/{form_id}/submissions")
def list_submissions(form_id: str, limit: int = 200, offset: int = 0,
                     db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "read")
    ver = current_version(db, form)
    rows = db.scalars(select(Submission).where(Submission.form_id == form.id,
                                               Submission.deleted_at.is_(None))
                      .order_by(Submission.created_at.desc()).limit(min(limit, 500)).offset(offset)).all()
    return {"schema": json.loads(ver.schema_json),
            "items": [submission_dto(s, json.loads(s.data_json)) for s in rows]}


@router.post("/forms/{form_id}/submissions", status_code=201)
def submit(form_id: str, payload: SubmitIn, request: Request,
           db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "read")
    sub = create_submission(db, form, payload.data, user, client_ip(request))
    log(db, user, "submission.created", "submission", sub.id, client_ip(request), form_id=form.id)
    return submission_dto(sub, json.loads(sub.data_json))


@router.get("/submissions/{submission_id}")
def get_submission(submission_id: str, db: Session = Depends(get_db),
                   user: User = Depends(get_current_user)):
    sub = get_submission_or_404(db, user, submission_id, "read")
    return submission_dto(sub, json.loads(sub.data_json))


@router.delete("/submissions/{submission_id}")
def delete_submission(submission_id: str, request: Request, db: Session = Depends(get_db),
                      user: User = Depends(get_current_user)):
    sub = get_submission_or_404(db, user, submission_id, "write")
    sub.deleted_at = utcnow()
    db.commit()
    log(db, user, "submission.deleted", "submission", sub.id, client_ip(request))
    return {"ok": True}


@router.get("/forms/{form_id}/submissions.csv")
def export_csv(form_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "read")
    schema = json.loads(current_version(db, form).schema_json)
    fields = [f for f in schema.get("fields", []) if f["type"] not in ("heading", "page_break")]

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["ردیف", "تاریخ ثبت"] + [f["label"] or f["key"] for f in fields])
    rows = db.scalars(select(Submission).where(Submission.form_id == form.id,
                                               Submission.deleted_at.is_(None))
                      .order_by(Submission.created_at)).all()
    for i, s in enumerate(rows, 1):
        data = json.loads(s.data_json)
        row = [i, s.created_at.strftime("%Y-%m-%d %H:%M")]
        for f in fields:
            val = data.get(f["key"], "")
            row.append(" | ".join(val) if isinstance(val, list) else val)
        writer.writerow(row)

    log(db, user, "submission.exported", "form", form.id, "", count=len(rows))
    return Response(
        content="\ufeff" + buf.getvalue(),           # BOM برای فارسی در Excel
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="submissions-{form.slug}.csv"'},
    )
