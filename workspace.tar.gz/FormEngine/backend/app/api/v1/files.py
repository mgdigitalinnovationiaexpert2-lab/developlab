"""فایل‌ها: آپلود با مجوز، دانلود با مجوز یا لینک امضاشدهٔ ۶۰ ثانیه‌ای."""
from __future__ import annotations

from fastapi import APIRouter, Depends, File, Form as FForm, HTTPException, Request, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, get_current_user
from app.core.guards import get_file_or_404
from app.core.permissions import get_path_or_404
from app.core.security import sign_download, verify_download
from app.db.session import get_db
from app.models import StoredFile, User
from app.schemas import file_dto
from app.services.audit import log
from app.services.storage import delete_physical, physical_path, save_upload

router = APIRouter(prefix="/files", tags=["files"])


@router.post("", status_code=201)
async def upload(request: Request, file: UploadFile = File(...), path_id: str = FForm(...),
                 form_id: str | None = FForm(None), db: Session = Depends(get_db),
                 user: User = Depends(get_current_user)):
    path = get_path_or_404(db, user, path_id, "write")
    rec = await save_upload(db, user, path, file, user.tenant_id, form_id=form_id)
    log(db, user, "file.uploaded", "file", rec.id, client_ip(request), size=rec.size)
    return file_dto(rec)


@router.get("")
def list_files(path_id: str | None = None, db: Session = Depends(get_db),
               user: User = Depends(get_current_user)):
    q = select(StoredFile).where(StoredFile.tenant_id == user.tenant_id)
    if path_id:
        get_path_or_404(db, user, path_id, "read")
        q = q.where(StoredFile.path_id == path_id)
        rows = db.scalars(q.order_by(StoredFile.created_at.desc())).all()
    else:
        rows = [r for r in db.scalars(q.order_by(StoredFile.created_at.desc())).all()
                if _can_read(db, user, r)]
    return [file_dto(r) for r in rows]


def _can_read(db: Session, user: User, rec: StoredFile) -> bool:
    try:
        get_file_or_404(db, user, rec.id, "read")
        return True
    except HTTPException:
        return False


@router.get("/{file_id}")
def file_info(file_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return file_dto(get_file_or_404(db, user, file_id, "read"))


@router.post("/{file_id}/link")
def make_link(file_id: str, request: Request, db: Session = Depends(get_db),
              user: User = Depends(get_current_user)):
    rec = get_file_or_404(db, user, file_id, "read")
    token = sign_download(rec.id, user.id)
    log(db, user, "file.link_issued", "file", rec.id, client_ip(request))
    return {"url": f"/api/v1/files/{rec.id}/download?token={token}",
            "expires_in": settings.download_link_seconds}


@router.get("/{file_id}/download")
def download(file_id: str, request: Request, token: str | None = None,
             db: Session = Depends(get_db)):
    if token:
        payload = verify_download(token)
        if not payload or payload.get("f") != file_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "فایل یافت نشد")
        rec = db.scalar(select(StoredFile).where(StoredFile.id == file_id))
        if rec is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "فایل یافت نشد")
        user = db.get(User, payload.get("s", ""))
        if user is None or not user.is_active:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "فایل یافت نشد")
        get_file_or_404(db, user, file_id, "read")     # مجوز لحظهٔ دانلود هم بررسی می‌شود
    else:
        user = get_current_user(request, db)
        rec = get_file_or_404(db, user, file_id, "read")

    path = physical_path(rec)
    if not path.exists():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "فایل یافت نشد")
    log(db, user, "file.downloaded", "file", rec.id, client_ip(request))
    return FileResponse(path, media_type="application/octet-stream", filename=rec.original_name,
                        headers={"X-Content-Type-Options": "nosniff"})


@router.delete("/{file_id}")
def remove(file_id: str, request: Request, db: Session = Depends(get_db),
           user: User = Depends(get_current_user)):
    rec = get_file_or_404(db, user, file_id, "write")
    delete_physical(rec)
    db.delete(rec)
    db.commit()
    log(db, user, "file.deleted", "file", file_id, client_ip(request))
    return {"ok": True}
