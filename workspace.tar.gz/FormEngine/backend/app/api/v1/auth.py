"""احراز هویت: ورود، خروج، تغییر رمز، پذیرش دعوت‌نامه. ثبت‌نام عمومی وجود ندارد."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, get_current_user
from app.core.security import (
    create_access_token, hash_password, needs_rehash, token_hash, utcnow, verify_password,
)
from app.db.session import get_db
from app.models import Invite, Tenant, User, UserSession
from app.schemas import AcceptInviteIn, ChangePasswordIn, LoginIn, tenant_dto, user_dto
from app.services.audit import log

router = APIRouter(prefix="/auth", tags=["auth"])


def _set_cookie(response: Response, token: str, expires) -> None:
    response.set_cookie(
        settings.cookie_name, token,
        max_age=int((expires - utcnow()).total_seconds()),
        httponly=True, secure=settings.cookie_secure, samesite=settings.cookie_samesite, path="/",
    )


def _find_user(db: Session, ident: str, tenant_slug: str | None) -> User | None:
    ident = ident.strip().lower()
    if tenant_slug:
        tenant = db.scalar(select(Tenant).where(Tenant.slug == tenant_slug.strip().lower()))
        if not tenant:
            return None
        return db.scalar(select(User).where(User.tenant_id == tenant.id, User.username == ident))
    if "/" in ident:                       # قالب tenant/username
        slug, uname = ident.split("/", 1)
        return _find_user(db, uname, slug)
    by_email = db.scalars(select(User).where(User.email == ident)).all()
    if len(by_email) == 1:
        return by_email[0]
    by_name = db.scalars(select(User).where(User.username == ident)).all()
    if len(by_name) == 1:
        return by_name[0]
    if len(by_name) > 1:
        raise HTTPException(status.HTTP_400_BAD_REQUEST,
                            "این نام کاربری در چند فضای کاری هست؛ از ایمیل یا قالب tenant/username استفاده کنید")
    return None


@router.post("/login")
def login(payload: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ip = client_ip(request)
    user = _find_user(db, payload.username, payload.tenant)

    if user is None:
        log(db, None, "login.failed", "user", "", ip, username=payload.username)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "نام کاربری یا رمز عبور نادرست است")

    if user.lockout_until and user.lockout_until > utcnow():
        raise HTTPException(status.HTTP_423_LOCKED,
                            "حساب موقتاً قفل است؛ چند دقیقهٔ دیگر تلاش کنید")
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "حساب شما غیرفعال شده است")

    if not verify_password(payload.password, user.password_hash):
        user.failed_count += 1
        if user.failed_count >= settings.lockout_attempts:
            user.lockout_until = utcnow() + timedelta(minutes=settings.lockout_minutes)
            user.failed_count = 0
            log(db, user, "account.locked", "user", user.id, ip)
        db.commit()
        log(db, user, "login.failed", "user", user.id, ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "نام کاربری یا رمز عبور نادرست است")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(payload.password)

    user.failed_count = 0
    user.lockout_until = None
    user.last_login_at = utcnow()

    sess = UserSession(user_id=user.id, ip=ip,
                       expires_at=utcnow() + timedelta(minutes=settings.access_token_minutes))
    db.add(sess)
    db.commit()
    db.refresh(sess)

    token, expires = create_access_token(user.id, user.tenant_id, user.role, sess.id)
    _set_cookie(response, token, expires)
    log(db, user, "login.success", "user", user.id, ip)

    tenant = db.get(Tenant, user.tenant_id)
    return {"user": user_dto(user), "tenant": tenant_dto(tenant)}


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db),
           user: User = Depends(get_current_user)):
    payload_token = request.cookies.get(settings.cookie_name)
    from app.core.security import decode_access_token
    payload = decode_access_token(payload_token or "") or {}
    sess = db.get(UserSession, payload.get("sid", ""))
    if sess:
        sess.revoked_at = utcnow()
        db.commit()
    response.delete_cookie(settings.cookie_name, path="/")
    log(db, user, "logout", "user", user.id, client_ip(request))
    return {"ok": True}


@router.get("/me")
def me(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return {"user": user_dto(user), "tenant": tenant_dto(db.get(Tenant, user.tenant_id))}


@router.post("/change-password")
def change_password(payload: ChangePasswordIn, request: Request, response: Response,
                    db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "رمز فعلی نادرست است")
    if len(payload.new_password) < settings.min_password_length:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "رمز جدید کوتاه است")
    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    db.commit()
    # ابطال همهٔ نشست‌های دیگر
    for s in db.scalars(select(UserSession).where(UserSession.user_id == user.id,
                                                 UserSession.revoked_at.is_(None))).all():
        s.revoked_at = utcnow()
    db.commit()
    log(db, user, "password.changed", "user", user.id, client_ip(request))
    response.delete_cookie(settings.cookie_name, path="/")
    return {"ok": True, "message": "رمز تغییر کرد؛ دوباره وارد شوید"}


@router.get("/invite/{token}")
def invite_info(token: str, db: Session = Depends(get_db)):
    inv = db.scalar(select(Invite).where(Invite.token_hash == token_hash(token)))
    if inv is None or inv.used_at or inv.expires_at < utcnow():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "دعوت‌نامه نامعتبر یا منقضی است")
    tenant = db.get(Tenant, inv.tenant_id)
    return {"username": inv.username, "full_name": inv.full_name, "role": inv.role,
            "tenant": tenant_dto(tenant), "expires_at": inv.expires_at.isoformat()}


@router.post("/invite/accept")
def invite_accept(payload: AcceptInviteIn, request: Request, db: Session = Depends(get_db)):
    inv = db.scalar(select(Invite).where(Invite.token_hash == token_hash(payload.token)))
    if inv is None or inv.used_at or inv.expires_at < utcnow():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "دعوت‌نامه نامعتبر یا منقضی است")
    if db.scalar(select(User).where(User.tenant_id == inv.tenant_id, User.username == inv.username)):
        raise HTTPException(status.HTTP_409_CONFLICT, "این نام کاربری قبلاً ساخته شده است")
    user = User(
        tenant_id=inv.tenant_id, username=inv.username.lower(), email=inv.email,
        full_name=payload.full_name or inv.full_name or inv.username,
        password_hash=hash_password(payload.password), role=inv.role,
    )
    inv.used_at = utcnow()
    db.add(user)
    db.commit()
    db.refresh(user)
    log(db, user, "invite.accepted", "user", user.id, client_ip(request))
    return {"ok": True, "user": user_dto(user)}
