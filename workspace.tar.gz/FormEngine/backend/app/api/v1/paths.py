"""مسیرها (پوشه‌های درختی) و اشتراک‌گذاری آن‌ها با اعضای مشخص."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import client_ip, get_current_user
from app.core.permissions import (
    effective_permission, get_path_or_404, readable_path_ids,
)
from app.db.session import get_db
from app.models import Form, PathNode, PathPermission, StoredFile, User
from app.schemas import PathCreateIn, PathUpdateIn, PermissionIn, path_dto
from app.services.audit import log
from app.services.storage import delete_physical

router = APIRouter(prefix="/paths", tags=["paths"])


def slugify(name: str) -> str:
    slug = re.sub(r"\s+", "-", name.strip().lower())
    slug = re.sub(r"[^\w\-\u0600-\u06FF]", "", slug, flags=re.UNICODE)
    return slug[:120] or "path"


def _unique_slug(db: Session, tenant_id: str, parent_id: str | None, base: str) -> str:
    slug, i = base, 2
    while db.scalar(select(PathNode).where(PathNode.tenant_id == tenant_id,
                                           PathNode.parent_id == parent_id,
                                           PathNode.slug == slug)):
        slug = f"{base}-{i}"
        i += 1
    return slug


@router.get("")
def list_paths(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    allowed = readable_path_ids(db, user)
    rows = db.scalars(select(PathNode).where(PathNode.tenant_id == user.tenant_id)).all()
    out = []
    for p in rows:
        if p.id in allowed:
            out.append(path_dto(p, effective_permission(db, user, p)))
    return out


@router.post("", status_code=201)
def create_path(payload: PathCreateIn, request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    if user.role == "viewer":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "نقش بیننده اجازهٔ ساخت مسیر ندارد")
    parent = None
    if payload.parent_id:
        parent = get_path_or_404(db, user, payload.parent_id, "write")
    node = PathNode(
        tenant_id=user.tenant_id, owner_id=user.id, parent_id=parent.id if parent else None,
        name=payload.name.strip(), visibility=payload.visibility,
        slug=_unique_slug(db, user.tenant_id, parent.id if parent else None, slugify(payload.name)),
    )
    db.add(node)
    db.commit()
    db.refresh(node)
    log(db, user, "path.created", "path", node.id, client_ip(request), name=node.name)
    return path_dto(node, "manage")


@router.patch("/{path_id}")
def update_path(path_id: str, payload: PathUpdateIn, request: Request,
                db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    node = get_path_or_404(db, user, path_id, "manage")
    if payload.name is not None:
        node.name = payload.name.strip()
    if payload.visibility is not None:
        node.visibility = payload.visibility
    db.commit()
    log(db, user, "path.updated", "path", node.id, client_ip(request))
    return path_dto(node, effective_permission(db, user, node))


@router.delete("/{path_id}")
def delete_path(path_id: str, request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    node = get_path_or_404(db, user, path_id, "manage")
    ids = {node.id}
    frontier = [node.id]
    while frontier:
        children = db.scalars(select(PathNode).where(PathNode.parent_id.in_(frontier),
                                                     PathNode.tenant_id == user.tenant_id)).all()
        frontier = [c.id for c in children if c.id not in ids]
        ids.update(frontier)

    for rec in db.scalars(select(StoredFile).where(StoredFile.path_id.in_(ids))).all():
        delete_physical(rec)
        db.delete(rec)
    db.delete(node)                      # فرزندان با ON DELETE CASCADE پاک می‌شوند
    db.commit()
    log(db, user, "path.deleted", "path", path_id, client_ip(request), descendants=len(ids))
    return {"ok": True, "deleted_paths": len(ids)}


@router.get("/{path_id}/permissions")
def list_permissions(path_id: str, db: Session = Depends(get_db),
                     user: User = Depends(get_current_user)):
    node = get_path_or_404(db, user, path_id, "manage")
    rows = db.scalars(select(PathPermission).where(PathPermission.path_id == node.id)).all()
    members = {u.id: u for u in db.scalars(select(User).where(User.tenant_id == user.tenant_id)).all()}
    return [{"user_id": r.user_id, "permission": r.permission,
             "username": members[r.user_id].username if r.user_id in members else "?",
             "full_name": members[r.user_id].full_name if r.user_id in members else ""} for r in rows]


@router.put("/{path_id}/permissions")
def grant_permission(path_id: str, payload: PermissionIn, request: Request,
                     db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    node = get_path_or_404(db, user, path_id, "manage")
    target = db.scalar(select(User).where(User.id == payload.user_id,
                                          User.tenant_id == user.tenant_id, User.is_active.is_(True)))
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "عضو یافت نشد")
    if target.id == node.owner_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "مالک مسیر همیشه دسترسی کامل دارد")

    grant = db.scalar(select(PathPermission).where(PathPermission.path_id == node.id,
                                                   PathPermission.user_id == target.id))
    if grant:
        grant.permission = payload.permission
    else:
        grant = PathPermission(path_id=node.id, user_id=target.id, permission=payload.permission)
        db.add(grant)
    if node.visibility == "private":
        node.visibility = "shared"
    db.commit()
    log(db, user, "path.shared", "path", node.id, client_ip(request),
        with_user=target.username, permission=payload.permission)
    return {"ok": True}


@router.delete("/{path_id}/permissions/{user_id}")
def revoke_permission(path_id: str, user_id: str, request: Request,
                      db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    node = get_path_or_404(db, user, path_id, "manage")
    grant = db.scalar(select(PathPermission).where(PathPermission.path_id == node.id,
                                                   PathPermission.user_id == user_id))
    if grant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "دسترسی‌ای یافت نشد")
    db.delete(grant)
    db.commit()
    log(db, user, "path.unshared", "path", node.id, client_ip(request), user_id=user_id)
    return {"ok": True}
