"""مدیریت اعضا — فقط مدیر همان فضای کاری. هیچ ثبت‌نام عمومی‌ای وجود ندارد."""
from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, get_current_user
from app.core.permissions import require_role
from app.core.security import hash_password, new_token, token_hash, utcnow
from app.db.session import get_db
from app.models import Form, Invite, PathNode, User, UserSession
from app.schemas import UserCreateIn, UserUpdateIn, user_dto
from app.services.audit import log

router = APIRouter(prefix="/users", tags=["users"])


def _admin(user: User) -> User:
    require_role(user, "owner", "admin")
    return user


def _revoke_sessions(db: Session, user_id: str) -> None:
    for s in db.scalars(select(UserSession).where(UserSession.user_id == user_id,
                                                 UserSession.revoked_at.is_(None))).all():
        s.revoked_at = utcnow()
    db.commit()


@router.get("")
def list_users(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """همهٔ اعضا فقط نام و نقش را می‌بینند (برای اشتراک‌گذاری مسیر لازم است)."""
    rows = db.scalars(select(User).where(User.tenant_id == user.tenant_id).order_by(User.created_at)).all()
    return [user_dto(u) for u in rows]


@router.post("", status_code=201)
def create_user(payload: UserCreateIn, request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    _admin(user)
    uname = payload.username.lower()
    if db.scalar(select(User).where(User.tenant_id == user.tenant_id, User.username == uname)):
        raise HTTPException(status.HTTP_409_CONFLICT, "این نام کاربری قبلاً وجود دارد")
    if payload.role == "owner":
        require_role(user, "owner")

    if payload.mode == "direct":
        if not payload.password or len(payload.password) < settings.min_password_length:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "رمز اولیهٔ معتبر لازم است")
        member = User(tenant_id=user.tenant_id, username=uname, email=payload.email,
                      full_name=payload.full_name or uname, role=payload.role,
                      password_hash=hash_password(payload.password), must_change_password=True)
        db.add(member)
        db.commit()
        db.refresh(member)
        log(db, user, "member.created", "user", member.id, client_ip(request), role=payload.role)
        return {"user": user_dto(member)}

    raw = new_token()
    inv = Invite(tenant_id=user.tenant_id, username=uname, email=payload.email,
                 full_name=payload.full_name, role=payload.role, token_hash=token_hash(raw),
                 expires_at=utcnow() + timedelta(hours=settings.invite_hours), created_by=user.id)
    db.add(inv)
    db.commit()
    log(db, user, "member.invited", "invite", inv.id, client_ip(request), username=uname)
    return {"invite": {"id": inv.id, "username": uname, "link": f"/invite/{raw}",
                       "expires_at": inv.expires_at.isoformat()}}


@router.patch("/{user_id}")
def update_user(user_id: str, payload: UserUpdateIn, request: Request,
                db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _admin(user)
    member = db.scalar(select(User).where(User.id == user_id, User.tenant_id == user.tenant_id))
    if member is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "عضو یافت نشد")
    if member.role == "owner" and user.role != "owner":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "تغییر مالک فقط توسط مالک ممکن است")

    if payload.full_name is not None:
        member.full_name = payload.full_name
    if payload.email is not None:
        member.email = payload.email
    if payload.role is not None:
        if payload.role == "owner":
            require_role(user, "owner")
        member.role = payload.role
    if payload.is_active is not None:
        member.is_active = payload.is_active
        if not payload.is_active:
            _revoke_sessions(db, member.id)
    db.commit()
    log(db, user, "member.updated", "user", member.id, client_ip(request))
    return user_dto(member)


@router.delete("/{user_id}")
def deactivate_user(user_id: str, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(get_current_user)):
    """غیرفعال‌سازی + انتقال مالکیت مسیرها/فرم‌ها به مدیر (داده پاک نمی‌شود)."""
    _admin(user)
    if user_id == user.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "خودتان را نمی‌توانید غیرفعال کنید")
    member = db.scalar(select(User).where(User.id == user_id, User.tenant_id == user.tenant_id))
    if member is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "عضو یافت نشد")
    if member.role == "owner":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "مالک فضای کاری غیرفعال نمی‌شود")

    member.is_active = False
    for p in db.scalars(select(PathNode).where(PathNode.owner_id == member.id)).all():
        p.owner_id = user.id
    for f in db.scalars(select(Form).where(Form.owner_id == member.id)).all():
        f.owner_id = user.id
    db.commit()
    _revoke_sessions(db, member.id)
    log(db, user, "member.deactivated", "user", member.id, client_ip(request))
    return {"ok": True}


@router.post("/{user_id}/reset-password")
def reset_password(user_id: str, request: Request, db: Session = Depends(get_db),
                   user: User = Depends(get_current_user)):
    _admin(user)
    member = db.scalar(select(User).where(User.id == user_id, User.tenant_id == user.tenant_id))
    if member is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "عضو یافت نشد")
    temp = new_token(9)
    member.password_hash = hash_password(temp)
    member.must_change_password = True
    member.failed_count = 0
    member.lockout_until = None
    db.commit()
    _revoke_sessions(db, member.id)
    log(db, user, "member.password_reset", "user", member.id, client_ip(request))
    return {"temporary_password": temp}


@router.get("/invites/list")
def list_invites(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _admin(user)
    rows = db.scalars(select(Invite).where(Invite.tenant_id == user.tenant_id,
                                           Invite.used_at.is_(None)).order_by(Invite.created_at.desc())).all()
    return [{"id": i.id, "username": i.username, "email": i.email, "role": i.role,
             "expires_at": i.expires_at.isoformat(), "expired": i.expires_at < utcnow()} for i in rows]


@router.delete("/invites/{invite_id}")
def revoke_invite(invite_id: str, request: Request, db: Session = Depends(get_db),
                  user: User = Depends(get_current_user)):
    _admin(user)
    inv = db.scalar(select(Invite).where(Invite.id == invite_id, Invite.tenant_id == user.tenant_id))
    if inv is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "دعوت‌نامه یافت نشد")
    db.delete(inv)
    db.commit()
    log(db, user, "invite.revoked", "invite", invite_id, client_ip(request))
    return {"ok": True}
