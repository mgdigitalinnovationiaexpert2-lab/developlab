from __future__ import annotations

import json

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.core.permissions import require_role
from app.db.session import get_db
from app.models import AuditLog, User

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("")
def list_audit(limit: int = 100, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    require_role(user, "owner", "admin")
    rows = db.scalars(select(AuditLog).where(AuditLog.tenant_id == user.tenant_id)
                      .order_by(AuditLog.created_at.desc()).limit(min(limit, 500))).all()
    names = {u.id: u.username for u in db.scalars(select(User).where(User.tenant_id == user.tenant_id)).all()}
    return [{"id": r.id, "action": r.action, "entity_type": r.entity_type, "entity_id": r.entity_id,
             "user": names.get(r.user_id, "ناشناس"), "ip": r.ip,
             "meta": json.loads(r.meta_json or "{}"),
             "at": r.created_at.isoformat()} for r in rows]
