"""نقاط پایانی عمومی فرم (لینک انتشار). فقط فرم‌های منتشرشدهٔ عمومی.

این تنها جایی است که بدون ورود قابل دسترسی است؛ هیچ فهرست مسیر/فایل/پاسخی
از اینجا بیرون نمی‌رود و فایل‌ها فقط با شناسهٔ همان فرم پذیرفته می‌شوند.
"""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import client_ip, get_optional_user
from app.core.guards import current_version
from app.db.session import get_db
from app.models import Form, PathNode, Tenant, User
from app.services.submissions import create_submission
from app.services.storage import save_upload

router = APIRouter(prefix="/public", tags=["public"])


def _public_form(db: Session, tenant_slug: str, form_slug: str) -> tuple[Form, PathNode]:
    tenant = db.scalar(select(Tenant).where(Tenant.slug == tenant_slug, Tenant.is_active.is_(True)))
    if tenant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "فرم یافت نشد")
    form = db.scalar(select(Form).where(Form.tenant_id == tenant.id, Form.slug == form_slug))
    if form is None or not form.public_enabled or form.status != "published":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "فرم یافت نشد")
    path = db.get(PathNode, form.path_id)
    if path is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "فرم یافت نشد")
    return form, path


@router.get("/{tenant_slug}/{form_slug}")
def public_form(tenant_slug: str, form_slug: str, db: Session = Depends(get_db),
                user: User | None = Depends(get_optional_user)):
    form, _ = _public_form(db, tenant_slug, form_slug)
    if form.require_login and user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "این فرم فقط برای اعضای واردشده باز است")
    schema = json.loads(current_version(db, form).schema_json)
    return {"title": form.title, "description": form.description, "schema": schema,
            "tenant": tenant_slug, "slug": form.slug, "version": form.current_version}


@router.post("/{tenant_slug}/{form_slug}/submit", status_code=201)
def public_submit(tenant_slug: str, form_slug: str, payload: dict, request: Request,
                  db: Session = Depends(get_db), user: User | None = Depends(get_optional_user)):
    form, _ = _public_form(db, tenant_slug, form_slug)
    if form.require_login and user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "برای ثبت پاسخ وارد شوید")
    sub = create_submission(db, form, payload.get("data", {}), user, client_ip(request))
    return {"ok": True, "id": sub.id, "message": "پاسخ شما ثبت شد"}


@router.post("/{tenant_slug}/{form_slug}/upload", status_code=201)
async def public_upload(tenant_slug: str, form_slug: str, request: Request,
                        file: UploadFile = File(...), db: Session = Depends(get_db),
                        user: User | None = Depends(get_optional_user)):
    form, path = _public_form(db, tenant_slug, form_slug)
    if form.require_login and user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "برای آپلود فایل وارد شوید")
    rec = await save_upload(db, user, path, file, form.tenant_id, form_id=form.id)
    return {"id": rec.id, "name": rec.original_name, "size": rec.size}
