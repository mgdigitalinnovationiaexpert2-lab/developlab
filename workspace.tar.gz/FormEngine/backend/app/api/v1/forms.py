"""فرم‌ها + نسخه‌بندی schema."""
from __future__ import annotations

import json
import re

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.deps import client_ip, get_current_user
from app.core.guards import current_version, get_form_or_404
from app.core.permissions import get_path_or_404, readable_path_ids
from app.db.session import get_db
from app.models import Form, FormVersion, Submission, User
from app.schemas import FormCreateIn, FormUpdateIn, form_dto
from app.services.audit import log
from app.services.form_schema import normalize_schema

router = APIRouter(prefix="/forms", tags=["forms"])


def _slug(db: Session, tenant_id: str, base: str) -> str:
    base = re.sub(r"\s+", "-", base.strip().lower())
    base = re.sub(r"[^\w\-\u0600-\u06FF]", "", base, flags=re.UNICODE)[:100] or "form"
    slug, i = base, 2
    while db.scalar(select(Form).where(Form.tenant_id == tenant_id, Form.slug == slug)):
        slug = f"{base}-{i}"
        i += 1
    return slug


def _counts(db: Session, form_ids: list[str]) -> dict[str, int]:
    if not form_ids:
        return {}
    rows = db.execute(
        select(Submission.form_id, func.count(Submission.id))
        .where(Submission.form_id.in_(form_ids), Submission.deleted_at.is_(None))
        .group_by(Submission.form_id)
    ).all()
    return {fid: n for fid, n in rows}


@router.get("")
def list_forms(path_id: str | None = None, db: Session = Depends(get_db),
               user: User = Depends(get_current_user)):
    allowed = readable_path_ids(db, user)
    q = select(Form).where(Form.tenant_id == user.tenant_id, Form.path_id.in_(allowed or {"-"}))
    if path_id:
        get_path_or_404(db, user, path_id, "read")
        q = q.where(Form.path_id == path_id)
    rows = db.scalars(q.order_by(Form.updated_at.desc())).all()
    counts = _counts(db, [f.id for f in rows])
    return [form_dto(f, counts) for f in rows]


@router.post("", status_code=201)
def create_form(payload: FormCreateIn, request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    path = get_path_or_404(db, user, payload.path_id, "write")
    try:
        schema = normalize_schema(payload.schema_ or {"fields": []})
    except ValueError as exc:
        raise HTTPException(422, str(exc))

    form = Form(tenant_id=user.tenant_id, path_id=path.id, owner_id=user.id,
                title=payload.title.strip(), description=payload.description,
                slug=_slug(db, user.tenant_id, payload.title))
    db.add(form)
    db.commit()
    db.refresh(form)
    db.add(FormVersion(form_id=form.id, version_no=1,
                       schema_json=json.dumps(schema, ensure_ascii=False), created_by=user.id))
    db.commit()
    log(db, user, "form.created", "form", form.id, client_ip(request), title=form.title)
    return form_dto(form)


@router.get("/{form_id}")
def get_form(form_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "read")
    ver = current_version(db, form)
    data = form_dto(form, _counts(db, [form.id]))
    data["schema"] = json.loads(ver.schema_json)
    return data


@router.put("/{form_id}")
def update_form(form_id: str, payload: FormUpdateIn, request: Request,
                db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "write")

    if payload.title is not None:
        form.title = payload.title.strip()
    if payload.description is not None:
        form.description = payload.description
    if payload.slug is not None and payload.slug != form.slug:
        form.slug = _slug(db, user.tenant_id, payload.slug)
    for attr in ("public_enabled", "require_login", "one_per_user", "status"):
        val = getattr(payload, attr)
        if val is not None:
            setattr(form, attr, val)

    if payload.schema_ is not None:
        try:
            schema = normalize_schema(payload.schema_)
        except ValueError as exc:
            raise HTTPException(422, str(exc))
        ver = current_version(db, form)
        if json.loads(ver.schema_json) != schema:
            form.current_version += 1
            db.add(FormVersion(form_id=form.id, version_no=form.current_version,
                               schema_json=json.dumps(schema, ensure_ascii=False), created_by=user.id))

    db.commit()
    db.refresh(form)
    log(db, user, "form.updated", "form", form.id, client_ip(request), version=form.current_version)
    out = form_dto(form, _counts(db, [form.id]))
    out["schema"] = json.loads(current_version(db, form).schema_json)
    return out


@router.get("/{form_id}/versions")
def form_versions(form_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "read")
    rows = db.scalars(select(FormVersion).where(FormVersion.form_id == form.id)
                      .order_by(FormVersion.version_no.desc())).all()
    return [{"version": v.version_no, "created_at": v.created_at.isoformat(),
             "fields": len(json.loads(v.schema_json).get("fields", []))} for v in rows]


@router.delete("/{form_id}")
def delete_form(form_id: str, request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    form, _ = get_form_or_404(db, user, form_id, "manage")
    db.delete(form)
    db.commit()
    log(db, user, "form.deleted", "form", form_id, client_ip(request))
    return {"ok": True}
