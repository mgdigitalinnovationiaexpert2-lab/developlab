"""Formobile · FormEngine — نقطهٔ ورود FastAPI.

اجرا:  uvicorn app.main:app --reload --port 8000
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.router import api_router
from app.core.config import settings
from app.db.init_db import init_db

@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(title=settings.app_name, docs_url="/api/docs",
              openapi_url="/api/openapi.json", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


app.include_router(api_router, prefix="/api/v1")


@app.get("/api/health")
def health():
    return {"ok": True, "app": settings.app_name}


# ---------- سرو کردن فرانت‌اند ساخته‌شده (React/Vite) ----------
DIST = Path(settings.frontend_dist)
if (DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")


@app.get("/{full_path:path}", include_in_schema=False)
def spa(full_path: str):
    if full_path.startswith("api/"):
        return JSONResponse({"detail": "یافت نشد"}, status_code=404)

    candidate = DIST / full_path
    if full_path and candidate.is_file():
        return FileResponse(candidate)

    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    return HTMLResponse(
        "<div style='font-family:Tahoma;direction:rtl;padding:40px'>"
        "<h2>فرانت‌اند هنوز ساخته نشده</h2>"
        "<p>در پوشهٔ <code>frontend</code> دستور <code>npm install && npm run build</code> را اجرا کنید،"
        " یا در حالت توسعه <code>npm run dev</code> (پورت ۵۱۷۳) را با پراکسی به این سرور اجرا کنید.</p>"
        "<p>مستندات API: <a href='/api/docs'>/api/docs</a></p></div>",
        status_code=200,
    )
