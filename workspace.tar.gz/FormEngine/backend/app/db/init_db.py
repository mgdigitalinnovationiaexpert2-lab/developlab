"""ساخت جدول‌ها + دادهٔ نمونهٔ دمو (فقط اگر دیتابیس خالی باشد).

در استقرار واقعی: FM_SEED=0 و ساخت مدیر اول از راه CLI.
"""
from __future__ import annotations

import json
import os
from datetime import timedelta

from sqlalchemy import select

from app.core.security import hash_password, utcnow
from app.services.form_schema import normalize_schema
from app.db.session import Base, SessionLocal, engine
from app.models import (
    Form, FormVersion, PathNode, PathPermission, Submission, Tenant, User,
)

DEMO_SCHEMA = {
    "title": "فرم ثبت‌نام ترم پاییز ۱۴۰۴",
    "fields": [
        {"id": "f1", "key": "full_name", "type": "text", "label": "نام و نام خانوادگی",
         "required": True, "max": 80, "placeholder": "مثال: مریم احمدی"},
        {"id": "f2", "key": "national_id", "type": "national_id", "label": "کد ملی",
         "required": True, "unique": True, "help": "۱۰ رقم، بدون خط تیره"},
        {"id": "f3", "key": "mobile", "type": "mobile", "label": "شمارهٔ موبایل", "required": True},
        {"id": "f4", "key": "birth_date", "type": "date_jalali", "label": "تاریخ تولد",
         "placeholder": "۱۳۸۰/۰۵/۱۲"},
        {"id": "f5", "key": "course", "type": "select", "label": "دورهٔ مورد نظر", "required": True,
         "options": ["ریاضی پیشرفته", "فیزیک", "زبان انگلیسی", "شیمی"]},
        {"id": "f6", "key": "gender", "type": "radio", "label": "جنسیت",
         "options": ["زن", "مرد"]},
        {"id": "f7", "key": "national_card", "type": "file", "label": "تصویر کارت ملی",
         "help": "jpg/png/pdf — حداکثر ۵ مگابایت"},
        {"id": "f8", "key": "note", "type": "textarea", "label": "توضیحات", "max": 500},
    ],
}

INTERVIEW_SCHEMA = {
    "title": "فرم مصاحبه",
    "fields": [
        {"id": "i1", "key": "candidate", "type": "text", "label": "نام متقاضی", "required": True},
        {"id": "i2", "key": "score", "type": "number", "label": "امتیاز مصاحبه", "min": 0, "max": 100},
        {"id": "i3", "key": "result", "type": "select", "label": "نتیجه",
         "options": ["پذیرفته", "در انتظار", "رد"]},
        {"id": "i4", "key": "reason", "type": "textarea", "label": "دلیل",
         "visible_when": {"key": "result", "equals": "رد"}},
    ],
}


def init_db(seed: bool | None = None) -> None:
    Base.metadata.create_all(bind=engine)
    seed = (os.getenv("FM_SEED", "1") == "1") if seed is None else seed
    if not seed:
        return
    db = SessionLocal()
    try:
        if db.scalar(select(Tenant).limit(1)):
            return
        _seed(db)
    finally:
        db.close()


def _add_form(db, tenant, path, owner, title, slug, schema, status="draft", public=False):
    form = Form(tenant_id=tenant.id, path_id=path.id, owner_id=owner.id, title=title, slug=slug,
                description="لطفاً اطلاعات را با دقت کامل کنید. فیلدهای ستاره‌دار الزامی هستند.",
                status=status, public_enabled=public, current_version=1)
    db.add(form)
    db.commit()
    db.refresh(form)
    ver = FormVersion(form_id=form.id, version_no=1,
                      schema_json=json.dumps(normalize_schema(schema), ensure_ascii=False), created_by=owner.id)
    db.add(ver)
    db.commit()
    db.refresh(ver)
    return form, ver


def _seed(db):
    t1 = Tenant(name="فرزدگان", slug="farzadegan")
    t2 = Tenant(name="آموزشگاه نمونهٔ دوم", slug="demo2")
    db.add_all([t1, t2])
    db.commit()

    farzad = User(tenant_id=t1.id, username="farzad", email="farzad@farzadegan.ir",
                  full_name="فرزاد فرزدگان", role="owner", password_hash=hash_password("farzad1234"))
    maryam = User(tenant_id=t1.id, username="maryam", email="maryam@farzadegan.ir",
                  full_name="مریم احمدی", role="editor", password_hash=hash_password("maryam1234"))
    ali = User(tenant_id=t1.id, username="ali", email="ali@farzadegan.ir",
               full_name="علی رضایی", role="viewer", password_hash=hash_password("ali1234"))
    reza = User(tenant_id=t2.id, username="reza", full_name="رضا کریمی", role="owner",
                password_hash=hash_password("reza1234"))
    db.add_all([farzad, maryam, ali, reza])
    db.commit()

    reg = PathNode(tenant_id=t1.id, owner_id=farzad.id, name="ثبت‌نام دوره‌ها", slug="registration",
                   visibility="shared")
    admin_path = PathNode(tenant_id=t1.id, owner_id=farzad.id, name="اداری و مالی", slug="admin-finance")
    maryam_path = PathNode(tenant_id=t1.id, owner_id=maryam.id, name="فرم‌های مریم", slug="maryam-forms")
    other = PathNode(tenant_id=t2.id, owner_id=reza.id, name="مسیر خصوصی رضا", slug="reza-private")
    db.add_all([reg, admin_path, maryam_path, other])
    db.commit()

    autumn = PathNode(tenant_id=t1.id, owner_id=farzad.id, parent_id=reg.id,
                      name="ترم پاییز", slug="autumn", visibility="shared")
    db.add(autumn)
    db.commit()

    db.add_all([
        PathPermission(path_id=reg.id, user_id=maryam.id, permission="write"),
        PathPermission(path_id=reg.id, user_id=ali.id, permission="read"),
    ])
    db.commit()

    f1, v1 = _add_form(db, t1, reg, farzad, "فرم ثبت‌نام ترم پاییز", "paeiz", DEMO_SCHEMA,
                       status="published", public=True)
    _add_form(db, t1, reg, farzad, "فرم مصاحبه", "interview", INTERVIEW_SCHEMA)
    _add_form(db, t1, admin_path, farzad, "درخواست مرخصی", "leave", {
        "fields": [
            {"id": "l1", "key": "employee", "type": "text", "label": "نام کارمند", "required": True},
            {"id": "l2", "key": "days", "type": "number", "label": "تعداد روز", "min": 1, "max": 30},
            {"id": "l3", "key": "from_date", "type": "date_jalali", "label": "از تاریخ"},
        ]})
    _add_form(db, t1, maryam_path, maryam, "فرم خصوصی مریم", "maryam-private", {
        "fields": [{"id": "m1", "key": "secret", "type": "text", "label": "یادداشت خصوصی"}]})
    _add_form(db, t2, other, reza, "فرم خصوصی فضای کاری دیگر", "other-tenant-form", {
        "fields": [{"id": "o1", "key": "x", "type": "text", "label": "فیلد نمونه"}]})

    samples = [
        {"full_name": "سارا کریمی", "national_id": "0079123457", "mobile": "09121234567",
         "birth_date": "1380/05/12", "course": "ریاضی پیشرفته", "gender": "زن"},
        {"full_name": "حسین مرادی", "national_id": "1234567891", "mobile": "09351112233",
         "birth_date": "1379/11/03", "course": "فیزیک", "gender": "مرد"},
        {"full_name": "نگار موسوی", "national_id": "0012345679", "mobile": "09197778899",
         "course": "زبان انگلیسی", "gender": "زن", "note": "درخواست کلاس عصر"},
    ]
    for i, data in enumerate(samples):
        db.add(Submission(tenant_id=t1.id, path_id=reg.id, form_id=f1.id, form_version_id=v1.id,
                          data_json=json.dumps(data, ensure_ascii=False), ip="127.0.0.1",
                          created_at=utcnow() - timedelta(days=i)))
    db.commit()
    print("✓ دادهٔ نمونه ساخته شد — farzad/farzad1234 · maryam/maryam1234 · ali/ali1234 · reza/reza1234")
