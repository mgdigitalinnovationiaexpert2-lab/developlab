"""منطق مشترک ثبت پاسخ (هم مسیر عمومی، هم مسیر احراز هویت‌شده)."""
from __future__ import annotations

import json

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.guards import current_version
from app.models import Form, StoredFile, Submission, User
from app.services.form_schema import validate_submission


def create_submission(db: Session, form: Form, data: dict, user: User | None, ip: str) -> Submission:
    if form.status != "published":
        raise HTTPException(status.HTTP_409_CONFLICT, "این فرم پذیرای پاسخ نیست")

    ver = current_version(db, form)
    schema = json.loads(ver.schema_json)
    cleaned, errors = validate_submission(schema, data)
    if errors:
        raise HTTPException(422, detail={"field_errors": errors})

    if form.one_per_user and user is not None:
        exists = db.scalar(select(Submission).where(Submission.form_id == form.id,
                                                    Submission.submitted_by == user.id,
                                                    Submission.deleted_at.is_(None)))
        if exists:
            raise HTTPException(status.HTTP_409_CONFLICT, "شما قبلاً به این فرم پاسخ داده‌اید")

    # یکتایی در سطح فرم
    for field in schema.get("fields", []):
        if field.get("unique") and field["key"] in cleaned:
            for prev in db.scalars(select(Submission).where(Submission.form_id == form.id,
                                                            Submission.deleted_at.is_(None))).all():
                if json.loads(prev.data_json).get(field["key"]) == cleaned[field["key"]]:
                    raise HTTPException(422,
                                        detail={"field_errors": {field["key"]: "این مقدار قبلاً ثبت شده است"}})

    sub = Submission(tenant_id=form.tenant_id, path_id=form.path_id, form_id=form.id,
                     form_version_id=ver.id, data_json=json.dumps(cleaned, ensure_ascii=False),
                     submitted_by=user.id if user else None, ip=ip)
    db.add(sub)
    db.commit()
    db.refresh(sub)

    # اتصال فایل‌های آپلودشده به این پاسخ (فقط فایل‌های همین فرم و همین فضای کاری)
    file_ids = [fid for v in cleaned.values() if isinstance(v, list) for fid in v
                if isinstance(fid, str) and len(fid) == 32]
    if file_ids:
        for rec in db.scalars(select(StoredFile).where(StoredFile.id.in_(file_ids),
                                                       StoredFile.tenant_id == form.tenant_id,
                                                       StoredFile.form_id == form.id)).all():
            rec.submission_id = sub.id
        db.commit()
    return sub
