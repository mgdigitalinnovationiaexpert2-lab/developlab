"""اعتبارسنجی سروری فرم — مرجع نهایی (کلاینت فقط راهنماست).

ساختار schema:
{
  "fields": [
     {"id":"f1","key":"full_name","type":"text","label":"نام","required":true,
      "options":[...], "min":0, "max":100, "pattern":"...", "help":"...",
      "visible_when": {"key":"x","equals":"بله"}}
  ]
}
"""
from __future__ import annotations

import re
from typing import Any

FIELD_TYPES = {
    "text", "textarea", "number", "email", "mobile", "national_id", "date_jalali",
    "select", "radio", "checkbox", "file", "signature", "heading", "page_break",
}
LAYOUT_TYPES = {"heading", "page_break"}

RE_MOBILE = re.compile(r"^09\d{9}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
RE_JALALI = re.compile(r"^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})$")
RE_KEY = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{0,63}$")

FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def to_latin_digits(value: str) -> str:
    return str(value).translate(FA_DIGITS)


def is_valid_national_id(code: str) -> bool:
    code = to_latin_digits(code).strip()
    if not re.fullmatch(r"\d{10}", code) or code == code[0] * 10:
        return False
    check = int(code[9])
    total = sum(int(code[i]) * (10 - i) for i in range(9)) % 11
    return (total < 2 and check == total) or (total >= 2 and check == 11 - total)


def is_valid_jalali(value: str) -> bool:
    m = RE_JALALI.match(to_latin_digits(value).strip())
    if not m:
        return False
    y, mo, d = (int(x) for x in m.groups())
    if not (1200 <= y <= 1500 and 1 <= mo <= 12 and 1 <= d <= 31):
        return False
    if mo > 6 and d > 30:
        return False
    return True


def normalize_schema(schema: dict[str, Any]) -> dict[str, Any]:
    fields = schema.get("fields") if isinstance(schema, dict) else None
    if not isinstance(fields, list):
        raise ValueError("schema باید شامل آرایهٔ fields باشد")
    seen: set[str] = set()
    clean = []
    for f in fields:
        if not isinstance(f, dict):
            raise ValueError("هر فیلد باید یک شیء باشد")
        ftype = f.get("type", "text")
        if ftype not in FIELD_TYPES:
            raise ValueError(f"نوع فیلد ناشناخته: {ftype}")
        key = str(f.get("key") or "").strip()
        if ftype not in LAYOUT_TYPES:
            if not RE_KEY.match(key):
                raise ValueError(f"کلید فیلد نامعتبر: {key!r} (حروف لاتین/عدد/underscore)")
            if key in seen:
                raise ValueError(f"کلید تکراری: {key}")
            seen.add(key)
        clean.append({
            "id": str(f.get("id") or key or ftype),
            "key": key,
            "type": ftype,
            "label": str(f.get("label") or "")[:200],
            "required": bool(f.get("required", False)),
            "help": str(f.get("help") or "")[:300],
            "placeholder": str(f.get("placeholder") or "")[:120],
            "options": [str(o)[:120] for o in (f.get("options") or [])][:200],
            "min": f.get("min"),
            "max": f.get("max"),
            "pattern": (str(f.get("pattern"))[:200] if f.get("pattern") else None),
            "unique": bool(f.get("unique", False)),
            "visible_when": f.get("visible_when") if isinstance(f.get("visible_when"), dict) else None,
        })
    return {"fields": clean, "title": str(schema.get("title") or "")[:200]}


def _visible(field: dict, data: dict) -> bool:
    cond = field.get("visible_when")
    if not cond:
        return True
    return str(data.get(cond.get("key", ""), "")) == str(cond.get("equals", ""))


def validate_submission(schema: dict, data: dict) -> tuple[dict, dict[str, str]]:
    """خروجی: (دادهٔ پاک‌سازی‌شده, خطاها به تفکیک کلید فیلد)"""
    errors: dict[str, str] = {}
    cleaned: dict[str, Any] = {}
    if not isinstance(data, dict):
        return {}, {"_": "ساختار داده نامعتبر است"}

    for f in schema.get("fields", []):
        ftype = f.get("type", "text")
        if ftype in LAYOUT_TYPES or not _visible(f, data):
            continue
        key = f.get("key") or f.get("id") or ""
        if not key:
            continue
        raw = data.get(key)
        empty = raw is None or (isinstance(raw, str) and not raw.strip()) or (isinstance(raw, list) and not raw)

        if empty:
            if f.get("required"):
                errors[key] = "این فیلد الزامی است"
            continue

        if ftype in ("text", "textarea", "signature"):
            val = str(raw)
            if ftype == "signature" and not val.startswith("data:image/"):
                errors[key] = "امضا نامعتبر است"
                continue
            if ftype != "signature":
                val = val.strip()
                mn, mx = f.get("min"), f.get("max")
                if mn is not None and len(val) < int(mn):
                    errors[key] = f"حداقل {mn} نویسه"
                    continue
                if mx is not None and len(val) > int(mx):
                    errors[key] = f"حداکثر {mx} نویسه"
                    continue
                if f.get("pattern"):
                    try:
                        if not re.search(f["pattern"], val):
                            errors[key] = "قالب واردشده درست نیست"
                            continue
                    except re.error:
                        pass
            cleaned[key] = val

        elif ftype == "number":
            try:
                num = float(to_latin_digits(str(raw)).replace(",", ""))
            except ValueError:
                errors[key] = "عدد وارد کنید"
                continue
            if f.get("min") is not None and num < float(f["min"]):
                errors[key] = f"حداقل {f['min']}"
                continue
            if f.get("max") is not None and num > float(f["max"]):
                errors[key] = f"حداکثر {f['max']}"
                continue
            cleaned[key] = num

        elif ftype == "email":
            val = str(raw).strip().lower()
            if not RE_EMAIL.match(val):
                errors[key] = "ایمیل معتبر نیست"
                continue
            cleaned[key] = val

        elif ftype == "mobile":
            val = to_latin_digits(str(raw)).strip().replace(" ", "").replace("-", "")
            if val.startswith("+98"):
                val = "0" + val[3:]
            if val.startswith("98") and len(val) == 12:
                val = "0" + val[2:]
            if not RE_MOBILE.match(val):
                errors[key] = "شمارهٔ موبایل معتبر نیست (۰۹xxxxxxxxx)"
                continue
            cleaned[key] = val

        elif ftype == "national_id":
            val = to_latin_digits(str(raw)).strip().replace("-", "").replace(" ", "")
            if not is_valid_national_id(val):
                errors[key] = "کد ملی معتبر نیست"
                continue
            cleaned[key] = val

        elif ftype == "date_jalali":
            val = to_latin_digits(str(raw)).strip()
            if not is_valid_jalali(val):
                errors[key] = "تاریخ شمسی معتبر نیست (۱۳۸۰/۰۵/۱۲)"
                continue
            cleaned[key] = val

        elif ftype in ("select", "radio"):
            val = str(raw)
            if f.get("options") and val not in f["options"]:
                errors[key] = "گزینهٔ انتخاب‌شده معتبر نیست"
                continue
            cleaned[key] = val

        elif ftype == "checkbox":
            vals = raw if isinstance(raw, list) else [raw]
            vals = [str(v) for v in vals]
            if f.get("options") and any(v not in f.get("options", []) for v in vals):
                errors[key] = "گزینهٔ انتخاب‌شده معتبر نیست"
                continue
            cleaned[key] = vals

        elif ftype == "file":
            vals = raw if isinstance(raw, list) else [raw]
            cleaned[key] = [str(v)[:32] for v in vals][:10]

    return cleaned, errors
