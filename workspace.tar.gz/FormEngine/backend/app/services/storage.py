"""ذخیره‌سازی امن فایل.

- نام فایل روی دیسک کاملاً تولیدشده است (uuid) → بدون Path Traversal
- پوشهٔ storage خارج از webroot و هرگز به‌صورت static mount نمی‌شود
- دانلود فقط از راه API با بررسی مجوز یا لینک امضاشدهٔ کوتاه‌مدت
"""
from __future__ import annotations

import hashlib
import re
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import PathNode, StoredFile, User

CHUNK = 1024 * 1024
SAFE_NAME = re.compile(r"[^\w.\-\u0600-\u06FF ]+", re.UNICODE)


def _safe_original(name: str) -> str:
    name = Path(name or "file").name
    name = SAFE_NAME.sub("_", name).strip() or "file"
    return name[:180]


def extension_of(name: str) -> str:
    return Path(name).suffix.lower().lstrip(".")


async def save_upload(db: Session, user: User | None, path: PathNode, upload: UploadFile,
                      tenant_id: str, form_id: str | None = None,
                      submission_id: str | None = None) -> StoredFile:
    original = _safe_original(upload.filename or "file")
    ext = extension_of(original)
    if ext not in settings.allowed_extensions:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                            f"پسوند .{ext} مجاز نیست")

    dest_dir = Path(settings.storage_dir) / tenant_id / path.id
    dest_dir.mkdir(parents=True, exist_ok=True)
    key = f"{tenant_id}/{path.id}/{uuid.uuid4().hex}.bin"
    dest = Path(settings.storage_dir) / key

    max_bytes = settings.max_upload_mb * 1024 * 1024
    size = 0
    digest = hashlib.sha256()
    try:
        with dest.open("wb") as out:
            while chunk := await upload.read(CHUNK):
                size += len(chunk)
                if size > max_bytes:
                    out.close()
                    dest.unlink(missing_ok=True)
                    raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                                        f"حداکثر حجم {settings.max_upload_mb} مگابایت")
                digest.update(chunk)
                out.write(chunk)
    finally:
        await upload.close()

    if size == 0:
        dest.unlink(missing_ok=True)
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "فایل خالی است")

    record = StoredFile(
        tenant_id=tenant_id, path_id=path.id, form_id=form_id, submission_id=submission_id,
        storage_key=key, original_name=original,
        content_type=(upload.content_type or "application/octet-stream")[:120],
        size=size, sha256=digest.hexdigest(), uploaded_by=user.id if user else None,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def physical_path(record: StoredFile) -> Path:
    return Path(settings.storage_dir) / record.storage_key


def delete_physical(record: StoredFile) -> None:
    physical_path(record).unlink(missing_ok=True)
