from __future__ import annotations

import json
from sqlalchemy.orm import Session

from app.models import AuditLog, User


def log(db: Session, user: User | None, action: str, entity_type: str = "", entity_id: str = "",
        ip: str = "", tenant_id: str | None = None, **meta) -> None:
    db.add(AuditLog(
        tenant_id=tenant_id or (user.tenant_id if user else None),
        user_id=user.id if user else None,
        action=action, entity_type=entity_type, entity_id=entity_id or "", ip=ip,
        meta_json=json.dumps(meta, ensure_ascii=False),
    ))
    db.commit()
