"""هش رمز (Argon2id)، توکن نشست (JWT) و امضای لینک دانلود فایل."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from datetime import datetime, timedelta, timezone

import jwt
from argon2 import PasswordHasher, Type
from argon2.exceptions import VerifyMismatchError, InvalidHashError

from app.core.config import settings

_ph = PasswordHasher(time_cost=2, memory_cost=65536, parallelism=2, type=Type.ID)


def hash_password(raw: str) -> str:
    return _ph.hash(raw)


def verify_password(raw: str, hashed: str) -> bool:
    try:
        return _ph.verify(hashed, raw)
    except (VerifyMismatchError, InvalidHashError, ValueError):
        return False


def needs_rehash(hashed: str) -> bool:
    try:
        return _ph.check_needs_rehash(hashed)
    except Exception:
        return True


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ---------- JWT نشست ----------
def create_access_token(user_id: str, tenant_id: str, role: str, session_id: str) -> tuple[str, datetime]:
    expires = utcnow() + timedelta(minutes=settings.access_token_minutes)
    payload = {
        "sub": user_id,
        "tid": tenant_id,
        "role": role,
        "sid": session_id,
        "exp": expires,
        "iat": utcnow(),
    }
    token = jwt.encode(payload, settings.secret_key, algorithm="HS256")
    return token, expires


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None


# ---------- لینک امضاشدهٔ دانلود ----------
def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))


def sign_download(file_id: str, subject: str, ttl: int | None = None) -> str:
    ttl = ttl or settings.download_link_seconds
    payload = {"f": file_id, "s": subject, "e": int(time.time()) + ttl}
    body = _b64(json.dumps(payload, separators=(",", ":")).encode())
    sig = _b64(hmac.new(settings.secret_key.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"


def verify_download(token: str) -> dict | None:
    try:
        body, sig = token.split(".", 1)
        expected = _b64(hmac.new(settings.secret_key.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(_unb64(body))
        if payload["e"] < int(time.time()):
            return None
        return payload
    except Exception:
        return None
