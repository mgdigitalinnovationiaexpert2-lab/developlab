"""تنظیمات مرکزی — همهٔ مقادیر با متغیر محیطی FM_* قابل بازنویسی‌اند."""
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="FM_", env_file=".env", extra="ignore")

    app_name: str = "Formobile · FormEngine"
    secret_key: str = "dev-only-change-me-in-production"

    # دیتابیس
    db_url: str = f"sqlite:///{BACKEND_DIR / 'data' / 'formengine.db'}"

    # نشست
    access_token_minutes: int = 480
    cookie_name: str = "fm_at"
    cookie_secure: bool = False          # روی HTTPS حتماً True
    cookie_samesite: str = "lax"

    # امنیت حساب
    lockout_attempts: int = 5
    lockout_minutes: int = 15
    invite_hours: int = 72
    min_password_length: int = 8

    # حریم خصوصی: آیا مدیر فضای کاری مسیرهای خصوصی دیگران را ببیند؟
    admin_can_view_private_paths: bool = False

    # فایل‌ها
    storage_dir: Path = BACKEND_DIR / "storage"
    max_upload_mb: int = 5
    download_link_seconds: int = 60
    allowed_extensions: list[str] = [
        "jpg", "jpeg", "png", "webp", "gif", "pdf",
        "doc", "docx", "xls", "xlsx", "csv", "txt", "zip",
    ]

    # فرانت‌اند
    frontend_dist: Path = BACKEND_DIR.parent / "frontend" / "dist"
    cors_origins: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]


settings = Settings()
settings.storage_dir.mkdir(parents=True, exist_ok=True)
(BACKEND_DIR / "data").mkdir(parents=True, exist_ok=True)
