"""موتور مجوزها — تنها نقطهٔ تصمیم‌گیری دربارهٔ دسترسی به مسیر.

هیچ روتری حق ندارد خودش دسترسی را حدس بزند؛ همه از این توابع عبور می‌کنند.
"""
from __future__ import annotations

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import PathNode, PathPermission, User, Tenant

RANK = {"read": 1, "write": 2, "manage": 3}
ADMIN_ROLES = {"owner", "admin"}


def ancestors(db: Session, path: PathNode) -> list[PathNode]:
    """زنجیرهٔ مسیر از خودش تا ریشه (برای ارث‌بری مجوز)."""
    chain = [path]
    seen = {path.id}
    cur = path
    while cur.parent_id and cur.parent_id not in seen:
        parent = db.get(PathNode, cur.parent_id)
        if parent is None:
            break
        chain.append(parent)
        seen.add(parent.id)
        cur = parent
    return chain


def effective_permission(db: Session, user: User, path: PathNode | None) -> str | None:
    if path is None or path.tenant_id != user.tenant_id:
        return None                      # فضای کاری دیگر → هیچ دسترسی‌ای
    if path.owner_id == user.id:
        return "manage"

    best: str | None = None
    for node in ancestors(db, path):
        grant = db.scalar(
            select(PathPermission).where(
                PathPermission.path_id == node.id, PathPermission.user_id == user.id
            )
        )
        if grant and (best is None or RANK[grant.permission] > RANK[best]):
            best = grant.permission
        if node.visibility == "tenant" and best is None:
            best = "read"

    if best is None and user.role in ADMIN_ROLES:
        tenant = db.get(Tenant, user.tenant_id)
        if tenant and tenant.admin_can_view_private_paths:
            best = "read"
    return best


def has(db: Session, user: User, path: PathNode | None, need: str = "read") -> bool:
    perm = effective_permission(db, user, path)
    return perm is not None and RANK[perm] >= RANK[need]


def get_path_or_404(db: Session, user: User, path_id: str, need: str = "read") -> PathNode:
    """منبع خارج از دسترس ⇒ 404 (نه 403) تا وجودش هم فاش نشود."""
    path = db.scalar(select(PathNode).where(PathNode.id == path_id, PathNode.tenant_id == user.tenant_id))
    if path is None or not has(db, user, path, need):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "مسیر یافت نشد")
    return path


def readable_path_ids(db: Session, user: User) -> set[str]:
    """همهٔ مسیری که کاربر می‌تواند ببیند (شامل زیرمسیرهای ارث‌بری‌شده)."""
    all_paths = db.scalars(select(PathNode).where(PathNode.tenant_id == user.tenant_id)).all()
    grants = db.scalars(select(PathPermission).where(PathPermission.user_id == user.id)).all()
    granted = {g.path_id: g.permission for g in grants}

    by_parent: dict[str | None, list[PathNode]] = {}
    for p in all_paths:
        by_parent.setdefault(p.parent_id, []).append(p)

    tenant = db.get(Tenant, user.tenant_id)
    admin_view = bool(tenant and tenant.admin_can_view_private_paths) and user.role in ADMIN_ROLES

    result: set[str] = set()

    def walk(node: PathNode, inherited: str | None):
        perm = inherited
        if node.owner_id == user.id:
            perm = "manage"
        if node.id in granted and (perm is None or RANK[granted[node.id]] > RANK[perm]):
            perm = granted[node.id]
        if node.visibility == "tenant" and perm is None:
            perm = "read"
        if perm is None and admin_view:
            perm = "read"
        if perm is not None:
            result.add(node.id)
        for child in by_parent.get(node.id, []):
            walk(child, perm)

    for root in by_parent.get(None, []):
        walk(root, None)
    return result


def require_role(user: User, *roles: str) -> None:
    if user.role not in roles:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "این عملیات برای نقش شما مجاز نیست")
