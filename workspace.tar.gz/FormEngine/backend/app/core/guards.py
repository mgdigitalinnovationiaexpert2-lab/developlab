"""نگهبان‌های مشترک: گرفتن موجودیت با بررسی مجوز (همیشه 404 برای منبع غیرمجاز)."""
from __future__ import annotations

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.permissions import get_path_or_404, has
from app.models import Form, FormVersion, PathNode, StoredFile, Submission, User

NOT_FOUND = status.HTTP_404_NOT_FOUND


def get_form_or_404(db: Session, user: User, form_id: str, need: str = "read") -> tuple[Form, PathNode]:
    form = db.scalar(select(Form).where(Form.id == form_id, Form.tenant_id == user.tenant_id))
    if form is None:
        raise HTTPException(NOT_FOUND, "فرم یافت نشد")
    path = get_path_or_404(db, user, form.path_id, need)
    return form, path


def get_submission_or_404(db: Session, user: User, submission_id: str, need: str = "read") -> Submission:
    sub = db.scalar(select(Submission).where(Submission.id == submission_id,
                                             Submission.tenant_id == user.tenant_id,
                                             Submission.deleted_at.is_(None)))
    if sub is None:
        raise HTTPException(NOT_FOUND, "پاسخ یافت نشد")
    get_path_or_404(db, user, sub.path_id, need)
    return sub


def get_file_or_404(db: Session, user: User, file_id: str, need: str = "read") -> StoredFile:
    record = db.scalar(select(StoredFile).where(StoredFile.id == file_id,
                                                StoredFile.tenant_id == user.tenant_id))
    if record is None:
        raise HTTPException(NOT_FOUND, "فایل یافت نشد")
    path = db.get(PathNode, record.path_id)
    if path is None or not has(db, user, path, need):
        raise HTTPException(NOT_FOUND, "فایل یافت نشد")
    return record


def current_version(db: Session, form: Form) -> FormVersion:
    ver = db.scalar(select(FormVersion).where(FormVersion.form_id == form.id,
                                              FormVersion.version_no == form.current_version))
    if ver is None:
        ver = FormVersion(form_id=form.id, version_no=form.current_version, schema_json='{"fields":[]}')
        db.add(ver)
        db.commit()
        db.refresh(ver)
    return ver
