"""مدل‌های ورودی (Pydantic) و سریالایزرهای خروجی."""
from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field

from app.models import Form, PathNode, StoredFile, Submission, User, Tenant

Role = Literal["owner", "admin", "editor", "viewer"]
Visibility = Literal["private", "shared", "tenant"]
Permission = Literal["read", "write", "manage"]


class LoginIn(BaseModel):
    username: str = Field(min_length=2, max_length=160)
    password: str = Field(min_length=1, max_length=200)
    tenant: str | None = None


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)


class AcceptInviteIn(BaseModel):
    token: str
    password: str = Field(min_length=8, max_length=200)
    full_name: str | None = None


class UserCreateIn(BaseModel):
    username: str = Field(min_length=2, max_length=60, pattern=r"^[a-zA-Z0-9._-]+$")
    full_name: str = ""
    email: str | None = None
    role: Role = "editor"
    mode: Literal["invite", "direct"] = "invite"
    password: str | None = None


class UserUpdateIn(BaseModel):
    full_name: str | None = None
    email: str | None = None
    role: Role | None = None
    is_active: bool | None = None


class PathCreateIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    parent_id: str | None = None
    visibility: Visibility = "private"


class PathUpdateIn(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    visibility: Visibility | None = None


class PermissionIn(BaseModel):
    user_id: str
    permission: Permission = "read"


class FormCreateIn(BaseModel):
    path_id: str
    title: str = Field(min_length=1, max_length=200)
    description: str = ""
    schema_: dict[str, Any] | None = Field(default=None, alias="schema")


class FormUpdateIn(BaseModel):
    title: str | None = None
    description: str | None = None
    slug: str | None = Field(default=None, max_length=120)
    schema_: dict[str, Any] | None = Field(default=None, alias="schema")
    public_enabled: bool | None = None
    require_login: bool | None = None
    one_per_user: bool | None = None
    status: Literal["draft", "published", "closed"] | None = None


class SubmitIn(BaseModel):
    data: dict[str, Any]


# ---------- سریالایزرها ----------
def user_dto(u: User) -> dict:
    return {
        "id": u.id, "username": u.username, "full_name": u.full_name, "email": u.email,
        "role": u.role, "is_active": u.is_active, "must_change_password": u.must_change_password,
        "last_login_at": u.last_login_at.isoformat() if u.last_login_at else None,
        "created_at": u.created_at.isoformat() if u.created_at else None,
    }


def tenant_dto(t: Tenant) -> dict:
    return {"id": t.id, "name": t.name, "slug": t.slug,
            "admin_can_view_private_paths": t.admin_can_view_private_paths}


def path_dto(p: PathNode, permission: str | None = None) -> dict:
    return {"id": p.id, "name": p.name, "slug": p.slug, "parent_id": p.parent_id,
            "owner_id": p.owner_id, "visibility": p.visibility, "permission": permission,
            "created_at": p.created_at.isoformat() if p.created_at else None}


def form_dto(f: Form, counts: dict[str, int] | None = None) -> dict:
    return {"id": f.id, "title": f.title, "description": f.description, "slug": f.slug,
            "path_id": f.path_id, "owner_id": f.owner_id, "status": f.status,
            "public_enabled": f.public_enabled, "require_login": f.require_login,
            "one_per_user": f.one_per_user, "version": f.current_version,
            "submissions": (counts or {}).get(f.id, 0),
            "updated_at": f.updated_at.isoformat() if f.updated_at else None}


def submission_dto(s: Submission, data: dict) -> dict:
    return {"id": s.id, "form_id": s.form_id, "data": data, "submitted_by": s.submitted_by,
            "ip": s.ip, "created_at": s.created_at.isoformat() if s.created_at else None}


def file_dto(f: StoredFile) -> dict:
    return {"id": f.id, "name": f.original_name, "size": f.size, "content_type": f.content_type,
            "path_id": f.path_id, "form_id": f.form_id, "submission_id": f.submission_id,
            "created_at": f.created_at.isoformat() if f.created_at else None}
