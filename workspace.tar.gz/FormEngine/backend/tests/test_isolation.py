"""آزمون‌های جداسازی داده (IDOR) — مهم‌ترین تست‌های این پروژه."""
import io
import json


def test_login_and_me(login):
    c = login("farzad")
    me = c.get("/api/v1/auth/me").json()
    assert me["user"]["username"] == "farzad"
    assert me["tenant"]["slug"] == "t1"


def test_wrong_password_and_lockout(client):
    for _ in range(3):
        r = client.post("/api/v1/auth/login", json={"username": "lockme", "password": "bad"})
        assert r.status_code == 401
    r = client.post("/api/v1/auth/login", json={"username": "lockme", "password": "pass1234"})
    assert r.status_code == 423          # قفل موقت


def test_user_cannot_list_other_users_paths(login, ids):
    farzad, maryam = login("farzad"), login("maryam")
    f_paths = {p["id"] for p in farzad.get("/api/v1/paths").json()}
    m_paths = {p["id"] for p in maryam.get("/api/v1/paths").json()}
    assert ids["paths"]["farzad"] in f_paths
    assert ids["paths"]["maryam"] not in f_paths      # مدیر مسیر خصوصی عضو را نمی‌بیند
    assert ids["paths"]["maryam"] in m_paths
    assert ids["paths"]["farzad"] not in m_paths


def test_direct_path_id_from_other_tenant_is_404(login, ids):
    reza = login("reza")
    assert reza.get("/api/v1/paths").json() == [
        p for p in reza.get("/api/v1/paths").json() if p["id"] == ids["paths"]["reza"]
    ]
    r = reza.put(f"/api/v1/paths/{ids['paths']['farzad']}/permissions",
                 json={"user_id": ids["users"]["reza"], "permission": "manage"})
    assert r.status_code == 404


def test_private_path_of_other_member_is_404(login, ids):
    farzad = login("farzad")
    r = farzad.patch(f"/api/v1/paths/{ids['paths']['maryam']}", json={"name": "هک"})
    assert r.status_code == 404


def test_share_grants_access_and_inherits_to_children(login, ids):
    farzad, maryam = login("farzad"), login("maryam")
    r = farzad.put(f"/api/v1/paths/{ids['paths']['farzad']}/permissions",
                   json={"user_id": ids["users"]["maryam"], "permission": "write"})
    assert r.status_code == 200
    assert ids["paths"]["farzad"] in {p["id"] for p in maryam.get("/api/v1/paths").json()}

    child = farzad.post("/api/v1/paths",
                        json={"name": "زیرمسیر", "parent_id": ids["paths"]["farzad"]}).json()
    assert child["id"] in {p["id"] for p in maryam.get("/api/v1/paths").json()}

    # لغو اشتراک → دسترسی زیرمسیر هم قطع می‌شود
    farzad.delete(f"/api/v1/paths/{ids['paths']['farzad']}/permissions/{ids['users']['maryam']}")
    assert child["id"] not in {p["id"] for p in maryam.get("/api/v1/paths").json()}


def test_viewer_cannot_create_form(login, ids):
    farzad, ali = login("farzad"), login("ali")
    farzad.put(f"/api/v1/paths/{ids['paths']['farzad']}/permissions",
               json={"user_id": ids["users"]["ali"], "permission": "read"})
    r = ali.post("/api/v1/forms", json={"path_id": ids["paths"]["farzad"], "title": "تلاش"})
    assert r.status_code == 404


def test_form_isolation_between_tenants(login, ids):
    farzad, reza = login("farzad"), login("reza")
    form = farzad.post("/api/v1/forms",
                       json={"path_id": ids["paths"]["farzad"], "title": "فرم محرمانه"}).json()
    assert reza.get(f"/api/v1/forms/{form['id']}").status_code == 404
    assert form["id"] not in {f["id"] for f in reza.get("/api/v1/forms").json()}


def test_submission_validation_and_isolation(login, ids):
    farzad, maryam = login("farzad"), login("maryam")
    schema = {"fields": [
        {"key": "national_id", "type": "national_id", "label": "کد ملی", "required": True},
        {"key": "mobile", "type": "mobile", "label": "موبایل", "required": True},
    ]}
    form = farzad.post("/api/v1/forms", json={"path_id": ids["paths"]["farzad"],
                                              "title": "اعتبارسنجی", "schema": schema}).json()
    farzad.put(f"/api/v1/forms/{form['id']}", json={"status": "published"})

    bad = farzad.post(f"/api/v1/forms/{form['id']}/submissions",
                      json={"data": {"national_id": "1111111111", "mobile": "123"}})
    assert bad.status_code == 422
    assert set(bad.json()["detail"]["field_errors"]) == {"national_id", "mobile"}

    good = farzad.post(f"/api/v1/forms/{form['id']}/submissions",
                       json={"data": {"national_id": "0079123457", "mobile": "۰۹۱۲۱۲۳۴۵۶۷"}})
    assert good.status_code == 201
    assert good.json()["data"]["mobile"] == "09121234567"

    assert maryam.get(f"/api/v1/forms/{form['id']}/submissions").status_code == 404


def test_public_form_flow(login, client, ids):
    farzad = login("farzad")
    schema = {"fields": [{"key": "name", "type": "text", "label": "نام", "required": True}]}
    form = farzad.post("/api/v1/forms", json={"path_id": ids["paths"]["farzad"],
                                              "title": "عمومی", "schema": schema}).json()
    # پیش‌نویس و غیرعمومی → 404
    assert client.get(f"/api/v1/public/t1/{form['slug']}").status_code == 404
    farzad.put(f"/api/v1/forms/{form['id']}", json={"status": "published", "public_enabled": True})
    assert client.get(f"/api/v1/public/t1/{form['slug']}").status_code == 200
    r = client.post(f"/api/v1/public/t1/{form['slug']}/submit", json={"data": {"name": "مهمان"}})
    assert r.status_code == 201
    # فضای کاری دیگر با همان اسلاگ → 404
    assert client.get(f"/api/v1/public/t2/{form['slug']}").status_code == 404


def test_file_upload_and_cross_user_download_is_404(login, ids):
    maryam, farzad = login("maryam"), login("farzad")
    up = maryam.post("/api/v1/files",
                     files={"file": ("سند.txt", io.BytesIO("محرمانه".encode()), "text/plain")},
                     data={"path_id": ids["paths"]["maryam"]})
    assert up.status_code == 201, up.text
    fid = up.json()["id"]

    assert farzad.get(f"/api/v1/files/{fid}").status_code == 404
    assert farzad.get(f"/api/v1/files/{fid}/download").status_code == 404

    link = maryam.post(f"/api/v1/files/{fid}/link").json()["url"]
    ok = maryam.get(link)
    assert ok.status_code == 200 and ok.content.decode() == "محرمانه"
    # لینک دستکاری‌شده
    assert maryam.get(link[:-4] + "AAAA").status_code == 404


def test_upload_rejects_bad_extension(login, ids):
    maryam = login("maryam")
    r = maryam.post("/api/v1/files",
                    files={"file": ("shell.php", io.BytesIO(b"<?php ?>"), "application/x-php")},
                    data={"path_id": ids["paths"]["maryam"]})
    assert r.status_code == 415


def test_admin_creates_member_and_deactivation_revokes_session(login, client, ids):
    farzad = login("farzad")
    created = farzad.post("/api/v1/users", json={"username": "sara", "role": "editor",
                                                 "mode": "direct", "password": "sara1234"})
    assert created.status_code == 201
    sara_id = created.json()["user"]["id"]

    sara = login("sara", "sara1234")
    assert sara.get("/api/v1/auth/me").status_code == 200

    farzad.delete(f"/api/v1/users/{sara_id}")
    assert sara.get("/api/v1/auth/me").status_code == 401


def test_editor_cannot_manage_members(login):
    maryam = login("maryam")
    assert maryam.post("/api/v1/users", json={"username": "xx", "mode": "direct",
                                              "password": "xxxx1234"}).status_code == 403
    assert maryam.get("/api/v1/audit").status_code == 403


def test_form_schema_versioning(login, ids):
    farzad = login("farzad")
    form = farzad.post("/api/v1/forms", json={
        "path_id": ids["paths"]["farzad"], "title": "نسخه‌دار",
        "schema": {"fields": [{"key": "a", "type": "text", "label": "الف"}]}}).json()
    assert form["version"] == 1
    updated = farzad.put(f"/api/v1/forms/{form['id']}", json={
        "schema": {"fields": [{"key": "a", "type": "text", "label": "الف"},
                              {"key": "b", "type": "number", "label": "ب"}]}}).json()
    assert updated["version"] == 2
    versions = farzad.get(f"/api/v1/forms/{form['id']}/versions").json()
    assert [v["version"] for v in versions] == [2, 1]
