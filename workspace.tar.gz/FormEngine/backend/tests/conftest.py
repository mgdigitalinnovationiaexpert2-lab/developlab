import os
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="formengine-test-"))
os.environ["FM_DB_URL"] = f"sqlite:///{TMP / 'test.db'}"
os.environ["FM_STORAGE_DIR"] = str(TMP / "storage")
os.environ["FM_SECRET_KEY"] = "test-secret-key-with-enough-length-32+"
os.environ["FM_SEED"] = "0"
os.environ["FM_LOCKOUT_ATTEMPTS"] = "3"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.db.init_db import init_db  # noqa: E402
from app.db.session import SessionLocal  # noqa: E402
from app.core.security import hash_password  # noqa: E402
from app.main import app  # noqa: E402
from app.models import PathNode, Tenant, User  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _setup():
    init_db(seed=False)
    db = SessionLocal()
    t1 = Tenant(name="فضای یک", slug="t1")
    t2 = Tenant(name="فضای دو", slug="t2")
    db.add_all([t1, t2])
    db.commit()

    users = {}
    for uname, tenant, role in [("farzad", t1, "owner"), ("maryam", t1, "editor"),
                                ("ali", t1, "viewer"), ("reza", t2, "owner"), ("lockme", t1, "editor")]:
        u = User(tenant_id=tenant.id, username=uname, full_name=uname, role=role,
                 password_hash=hash_password("pass1234"))
        db.add(u)
        db.commit()
        db.refresh(u)
        users[uname] = u.id

    p_farzad = PathNode(tenant_id=t1.id, owner_id=users["farzad"], name="مسیر فرزاد", slug="f")
    p_maryam = PathNode(tenant_id=t1.id, owner_id=users["maryam"], name="مسیر مریم", slug="m")
    p_reza = PathNode(tenant_id=t2.id, owner_id=users["reza"], name="مسیر رضا", slug="r")
    db.add_all([p_farzad, p_maryam, p_reza])
    db.commit()
    data = {"tenants": {"t1": t1.id, "t2": t2.id}, "users": users,
            "paths": {"farzad": p_farzad.id, "maryam": p_maryam.id, "reza": p_reza.id}}
    db.close()
    yield data


@pytest.fixture(scope="session")
def ids(_setup):
    return _setup


@pytest.fixture()
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def login(client):
    def _login(username: str, password: str = "pass1234") -> TestClient:
        c = TestClient(app)
        r = c.post("/api/v1/auth/login", json={"username": username, "password": password})
        assert r.status_code == 200, r.text
        return c
    return _login
