# Formobile · FormEngine — هستهٔ احراز هویت + فرم‌ساز (FastAPI + React/Vite + SQLite)

این پوشه یک **برش عمودی کامل و قابل اجرا** از چیزی است که خواستید:
احراز هویت، مدیریت اعضا توسط مدیر هر فضای کاری، مسیرهای خصوصی per کاربر با امکان اشتراک‌گذاری،
فرم‌ساز نسخه‌دار، پاسخ‌ها و آپلود/دانلود امن فایل — با پوستهٔ ظاهری شبیه Sci-Hub و لوگوی Formobile.

> ساختار لایه‌ای (`api / core / models / schemas / services / db` در بک‌اند و `pages / components` در فرانت)
> عمداً انتخاب شده تا بعد از دیدن پروژهٔ اصلی شما، **فایل‌به‌فایل روی تفکیک پوشه‌های موجود نشانده شود**
> و چیزی جابه‌جا نشود. راهنمای ادغام: `MERGE-fa.md`.

---

## ۱) اجرا روی ویندوز (سیستم شما)

```bat
cd C:\Farzadegan\FormEngine\backend
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --reload --port 8000
```

فرانت‌اند (ترمینال دوم):

```bat
cd C:\Farzadegan\FormEngine\frontend
npm install
npm run dev
```

* حالت توسعه: فرانت روی `http://localhost:5173` و API روی `http://localhost:8000`
  (پراکسی `/api` در `vite.config.js` تنظیم شده؛ مرورگر فقط آدرس نسبی می‌بیند).
* حالت یک‌پورتی: `npm run build` بزنید؛ بعد FastAPI خودش `frontend/dist` را سرو می‌کند → فقط `http://localhost:8000`.
* مستندات تعاملی API: `http://localhost:8000/api/docs`

اسکریپت‌های آماده: `run-backend.bat` و `run-frontend.bat`.

### حساب‌های نمونه (دادهٔ دمو)

| فضای کاری | کاربر | رمز | نقش |
|---|---|---|---|
| farzadegan | `farzad` | `farzad1234` | مالک/مدیر |
| farzadegan | `maryam` | `maryam1234` | سازنده (دسترسی write به «ثبت‌نام دوره‌ها») |
| farzadegan | `ali` | `ali1234` | بیننده (فقط read همان مسیر) |
| demo2 | `reza` | `reza1234` | مالک فضای کاری دیگر — برای تست جداسازی |

لینک فرم عمومی نمونه: `http://localhost:8000/f/farzadegan/paeiz`

برای خاموش کردن دادهٔ دمو: متغیر محیطی `FM_SEED=0`.

---

## ۲) چه چیزهایی کار می‌کند

**احراز هویت**
- ورود با نام کاربری/ایمیل (یا قالب `tenant/username`)، کوکی `HttpOnly` + رکورد نشست در دیتابیس
- Argon2id، قفل پلکانی حساب (۵ تلاش / ۱۵ دقیقه)، تغییر رمز + ابطال بقیهٔ نشست‌ها
- **بدون ثبت‌نام عمومی**: عضو فقط با دعوت‌نامهٔ یک‌بارمصرف (۷۲ ساعت) یا ساخت مستقیم توسط مدیر
- غیرفعال‌سازی عضو ⇒ ابطال فوری نشست + انتقال مالکیت مسیرها/فرم‌ها به مدیر
- بازنشانی رمز توسط مدیر با رمز موقت و اجبار تغییر در اولین ورود

**جداسازی داده (خواستهٔ اصلی شما)**
- سه کلید: `TenantId` (فضای کاری) + `PathId` (مسیر) + `OwnerId` (مالک)
- مسیر پیش‌فرض `private` است؛ فقط مالک می‌بیند. با «اشتراک‌گذاری مسیر» به عضو مشخص `read/write/manage` داده می‌شود
- دسترسی به زیرمسیرها **ارث** می‌رسد و با لغو اشتراک پدر، فوراً قطع می‌شود
- مدیر فضای کاری پیش‌فرض مسیرهای خصوصی دیگران را **نمی‌بیند** (`admin_can_view_private_paths=False`، قابل تغییر)
- منبع غیرمجاز ⇒ **404** (نه 403) تا وجود فرم/فایل هم فاش نشود
- فایل‌ها با نام تولیدشده در `storage/{tenant}/{path}/{uuid}.bin` ذخیره می‌شوند؛ سرو مستقیم استاتیک ندارند
- دانلود: بررسی مجوز لحظه‌ای، یا لینک امضاشدهٔ HMAC با انقضای ۶۰ ثانیه
- آپلود: لیست سفید پسوند، سقف حجم، هش SHA-256، جلوگیری از Path Traversal

**فرم‌ساز**
- کشیدن‌ورها کردن فیلد، مرتب‌سازی، حذف، پنل ویژگی‌ها
- انواع: متن کوتاه/بلند، عدد، ایمیل، موبایل، **کد ملی (الگوریتمی)**، **تاریخ شمسی**، کشویی، تک/چندانتخابی، فایل، **امضا (بوم لمسی)**، عنوان، شکست صفحه
- الزامی، یکتا، حداقل/حداکثر، الگو، **نمایش شرطی**
- اعتبارسنجی سمت سرور مرجع است؛ ارقام فارسی/عربی خودکار لاتین می‌شوند
- نسخه‌بندی schema (`form_versions`) و اتصال هر پاسخ به نسخهٔ زمان ثبت
- انتشار: پیش‌نویس/منتشرشده/بسته + لینک عمومی `/f/{tenant}/{slug}` + «فقط کاربران واردشده» + «هر کاربر یک پاسخ»
- پاسخ‌ها: جدول، جزئیات، حذف نرم، **خروجی CSV سازگار با Excel فارسی (BOM)**
- گزارش رویدادها (Audit) برای مدیر

---

## ۳) تست‌ها

```bat
cd backend
.venv\Scripts\python -m pytest tests -q
```

۱۵ تست سبز، از جمله تست‌های IDOR:
دسترسی کاربر به مسیر/فرم/فایل کاربر دیگر (هم‌فضا و فضای دیگر)، ارث‌بری و لغو اشتراک،
قفل حساب، اعتبارسنجی کد ملی/موبایل، لینک امضاشدهٔ دستکاری‌شده، پسوند غیرمجاز،
ابطال نشست پس از غیرفعال‌سازی، نسخه‌بندی فرم.

---

## ۴) ساختار پوشه‌ها

```
FormEngine/
├─ backend/
│  ├─ app/
│  │  ├─ main.py               ← ورودی FastAPI + سرو فرانت + هدرهای امنیتی
│  │  ├─ api/
│  │  │  ├─ router.py
│  │  │  └─ v1/  auth · users · paths · forms · submissions · files · audit · public
│  │  ├─ core/  config · security · deps · permissions · guards
│  │  ├─ models/               ← SQLAlchemy (Tenant, User, PathNode, Form, Submission, StoredFile, …)
│  │  ├─ schemas/              ← Pydantic ورودی + سریالایزر خروجی
│  │  ├─ services/             ← storage · form_schema · submissions · audit
│  │  └─ db/    session · init_db
│  ├─ tests/    conftest · test_isolation
│  └─ requirements.txt
├─ frontend/
│  ├─ src/
│  │  ├─ api.js  theme.css  App.jsx  main.jsx
│  │  ├─ components/  Layout · FieldInput (+ بوم امضا)
│  │  └─ pages/  Login · Invite · ChangePassword · Workspace · Builder · Responses · Members · Audit · PublicForm
│  ├─ public/logo.png          ← لوگوی خودتان
│  ├─ index.html  vite.config.js  package.json
└─ design/formobile-ui-preview.html  ← پوستهٔ استاتیک اولیه (برای مقایسهٔ طراحی)
```

---

## ۵) اسکرین‌شات‌ها و بررسی بصری خودکار

پوشهٔ `design/screenshots/` شامل ۱۰ تصویر واقعی از برنامه در حال اجراست:
ورود، میزکار مدیر، مودال اشتراک‌گذاری، فرم‌ساز، اعضا، پاسخ‌ها، گزارش رویدادها،
میزکار عضو دیگر (اثبات جداسازی)، فرم عمومی و اعتبارسنجی سرور.

برای بازتولید آن‌ها (اختیاری، فقط برای توسعه):

```bat
cd frontend
npm i -D playwright
npx playwright install chromium
node scripts/visual-check.cjs
```

فونت فارسی **Vazirmatn** به‌صورت محلی در `frontend/public/fonts` قرار دارد؛
هیچ درخواستی به CDN در زمان اجرا ارسال نمی‌شود (مجوز OFL در همان پوشه).

---

## ۶) کارهای باقی‌مانده (پیشنهاد ترتیب)

1. **ادغام با پروژهٔ موجود شما** — نیاز به zip یا درخت پوشه‌ها دارد (`MERGE-fa.md`)
2. مهاجرت دیتابیس با Alembic (الان `create_all` است؛ برای پروژهٔ واقعی Migration لازم است)
3. ارسال واقعی ایمیل دعوت‌نامه (SMTP) + فراموشی رمز با توکن یک‌بارمصرف
4. تأیید دومرحله‌ای TOTP برای مدیر
5. Rate limit روی آپلود/ثبت پاسخ عمومی + CAPTCHA
6. پشتیبان‌گیری زمان‌بندی‌شده از SQLite (`VACUUM INTO`) و پوشهٔ storage
7. هدرهای امنیتی سخت‌گیرانه در تولید: `FM_COOKIE_SECURE=1`، HSTS، CSP، `X-Frame-Options`
