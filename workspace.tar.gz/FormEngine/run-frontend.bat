@echo off
REM ---- اجرای فرانت‌اند Formobile (حالت توسعه) ----
cd /d %~dp0frontend
if not exist node_modules (
  echo Installing npm packages...
  call npm install
)
echo Frontend: http://localhost:5173  (proxy /api -> 127.0.0.1:8000)
call npm run dev
