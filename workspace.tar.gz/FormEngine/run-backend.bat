@echo off
REM ---- اجرای بک‌اند Formobile روی ویندوز ----
cd /d %~dp0backend
if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\pip install -r requirements.txt
)
echo Backend: http://localhost:8000  (API docs: /api/docs)
.venv\Scripts\python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
