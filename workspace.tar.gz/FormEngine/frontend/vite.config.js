import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// در حالت توسعه، فرانت روی 5173 و API روی 8000 است؛ مرورگر فقط آدرس نسبی می‌بیند.
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  build: { outDir: 'dist', emptyOutDir: true },
})
