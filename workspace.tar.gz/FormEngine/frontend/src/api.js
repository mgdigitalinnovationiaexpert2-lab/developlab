const BASE = '/api/v1'

export class ApiError extends Error {
  constructor(message, status, detail) {
    super(message)
    this.status = status
    this.detail = detail
    this.fieldErrors = (detail && detail.field_errors) || null
  }
}

export async function api(path, { method = 'GET', body } = {}) {
  const opts = { method, credentials: 'include', headers: {} }
  if (body instanceof FormData) {
    opts.body = body
  } else if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json'
    opts.body = JSON.stringify(body)
  }
  const res = await fetch(BASE + path, opts)
  const ct = res.headers.get('content-type') || ''
  const data = ct.includes('application/json') ? await res.json() : await res.text()
  if (!res.ok) {
    const detail = data && data.detail
    let msg = 'خطای نامشخص'
    if (typeof detail === 'string') msg = detail
    else if (detail && detail.field_errors) msg = 'لطفاً خطاهای فیلدها را برطرف کنید'
    else if (Array.isArray(detail) && detail[0]?.msg) msg = detail[0].msg
    throw new ApiError(msg, res.status, detail)
  }
  return data
}

export const faDate = (iso) => {
  if (!iso) return '—'
  try {
    return new Date(iso + (iso.endsWith('Z') ? '' : 'Z')).toLocaleString('fa-IR', {
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
    })
  } catch { return iso }
}

export const ROLE_FA = { owner: 'مالک', admin: 'مدیر', editor: 'سازنده', viewer: 'بیننده' }
export const STATUS_FA = { draft: 'پیش‌نویس', published: 'منتشرشده', closed: 'بسته' }
export const PERM_FA = { read: 'فقط مشاهده', write: 'ویرایش', manage: 'مدیریت کامل' }
export const VIS_FA = { private: 'خصوصی', shared: 'اشتراکی', tenant: 'همهٔ اعضا' }
