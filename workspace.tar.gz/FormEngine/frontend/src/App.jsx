import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { api } from './api.js'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import Invite from './pages/Invite.jsx'
import ChangePassword from './pages/ChangePassword.jsx'
import Workspace from './pages/Workspace.jsx'
import Builder from './pages/Builder.jsx'
import Responses from './pages/Responses.jsx'
import Members from './pages/Members.jsx'
import Audit from './pages/Audit.jsx'
import PublicForm from './pages/PublicForm.jsx'

const AuthCtx = createContext(null)
export const useAuth = () => useContext(AuthCtx)

function Loading() {
  return <div style={{ padding: 40, color: '#6b6b6b' }}>در حال بارگذاری…</div>
}

function Protected({ children, adminOnly = false }) {
  const { user, loading } = useAuth()
  const loc = useLocation()
  if (loading) return <Loading />
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  if (user.must_change_password) return <Navigate to="/change-password" replace />
  if (adminOnly && !['owner', 'admin'].includes(user.role)) return <Navigate to="/" replace />
  return children
}

export default function App() {
  const [user, setUser] = useState(null)
  const [tenant, setTenant] = useState(null)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(async () => {
    try {
      const data = await api('/auth/me')
      setUser(data.user); setTenant(data.tenant)
    } catch {
      setUser(null); setTenant(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { refresh() }, [refresh])

  const logout = async () => {
    try { await api('/auth/logout', { method: 'POST' }) } catch { /* نادیده */ }
    setUser(null); setTenant(null)
  }

  return (
    <AuthCtx.Provider value={{ user, tenant, loading, setUser, setTenant, refresh, logout }}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/invite/:token" element={<Invite />} />
        <Route path="/f/:tenantSlug/:formSlug" element={<PublicForm />} />
        <Route path="/change-password" element={<Protected><ChangePassword /></Protected>} />
        <Route element={<Protected><Layout /></Protected>}>
          <Route path="/" element={<Workspace />} />
          <Route path="/forms/:id/edit" element={<Builder />} />
          <Route path="/forms/:id/responses" element={<Responses />} />
          <Route path="/members" element={<Protected adminOnly><Members /></Protected>} />
          <Route path="/audit" element={<Protected adminOnly><Audit /></Protected>} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthCtx.Provider>
  )
}
