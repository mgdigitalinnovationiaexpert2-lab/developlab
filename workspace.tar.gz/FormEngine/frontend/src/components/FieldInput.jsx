import React, { useState } from 'react'
import { api } from '../api.js'

/** رندر یک فیلد بر اساس نوع — هم در پیش‌نمایش فرم‌ساز و هم در فرم عمومی. */
export default function FieldInput({ field, value, onChange, error, uploadCtx }) {
  const [busy, setBusy] = useState(false)
  const [uploadErr, setUploadErr] = useState('')
  const [names, setNames] = useState([])
  const f = field
  const common = { className: 'inp', placeholder: f.placeholder || '', id: `f-${f.key}` }

  if (f.type === 'heading') return <h3 style={{ fontSize: 14, margin: '10px 0 4px' }}>{f.label}</h3>
  if (f.type === 'page_break') return <hr style={{ border: 0, borderTop: '1px dashed var(--line)', margin: '14px 0' }} />

  let control = null
  if (f.type === 'textarea') {
    control = <textarea {...common} value={value || ''} onChange={(e) => onChange(e.target.value)} />
  } else if (f.type === 'select') {
    control = (
      <select {...common} value={value || ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">— انتخاب کنید —</option>
        {(f.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    )
  } else if (f.type === 'radio') {
    control = (
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        {(f.options || []).map((o) => (
          <label key={o} style={{ fontSize: 13 }}>
            <input type="radio" name={f.key} checked={value === o} onChange={() => onChange(o)} /> {o}
          </label>
        ))}
      </div>
    )
  } else if (f.type === 'checkbox') {
    const arr = Array.isArray(value) ? value : []
    control = (
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        {(f.options || []).map((o) => (
          <label key={o} style={{ fontSize: 13 }}>
            <input type="checkbox" checked={arr.includes(o)}
              onChange={(e) => onChange(e.target.checked ? [...arr, o] : arr.filter((x) => x !== o))} /> {o}
          </label>
        ))}
      </div>
    )
  } else if (f.type === 'file') {
    const files = Array.isArray(value) ? value : []
    control = (
      <div className="file-pick">
        <label className="btn sm ghost" style={{ cursor: 'pointer' }}>
          {busy ? 'در حال آپلود…' : 'انتخاب فایل…'}
          <input type="file" style={{ display: 'none' }} disabled={busy}
            onChange={async (e) => {
              const file = e.target.files?.[0]
              if (!file || !uploadCtx) return
              setBusy(true); setUploadErr('')
              try {
                const fd = new FormData()
                fd.append('file', file)
                const rec = await uploadCtx(fd)
                setNames((n) => [...n, rec.name])
                onChange([...files, rec.id])
              } catch (err) { setUploadErr(err.message) } finally { setBusy(false); e.target.value = '' }
            }} />
        </label>
        <span className="hint">
          {names.length ? names.join('، ') : (files.length ? `${files.length} فایل پیوست شد` : 'فایلی انتخاب نشده')}
        </span>
        {!uploadCtx && <span className="hint">(آپلود در پیش‌نمایش غیرفعال است)</span>}
        {uploadErr && <div className="field-err">{uploadErr}</div>}
      </div>
    )
  } else if (f.type === 'signature') {
    control = (
      <div>
        <SignaturePad value={value} onChange={onChange} />
      </div>
    )
  } else {
    const type = f.type === 'number' ? 'text' : f.type === 'email' ? 'email' : 'text'
    const mono = ['number', 'email', 'mobile', 'national_id'].includes(f.type)
    control = (
      <input {...common} type={type} className={`inp${mono ? ' mono' : ''}`}
        value={value || ''} onChange={(e) => onChange(e.target.value)} />
    )
  }

  return (
    <div className="field">
      <label htmlFor={`f-${f.key}`}>{f.label || f.key} {f.required && <span className="req">*</span>}</label>
      {control}
      {f.help && <div className="hint">{f.help}</div>}
      {error && <div className="field-err">{error}</div>}
    </div>
  )
}

function SignaturePad({ value, onChange }) {
  const [drawing, setDrawing] = React.useState(false)
  const ref = React.useRef(null)

  const pos = (e) => {
    const r = ref.current.getBoundingClientRect()
    const p = e.touches ? e.touches[0] : e
    return { x: p.clientX - r.left, y: p.clientY - r.top }
  }
  const start = (e) => {
    e.preventDefault()
    const ctx = ref.current.getContext('2d')
    ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#141414'
    const { x, y } = pos(e); ctx.beginPath(); ctx.moveTo(x, y); setDrawing(true)
  }
  const move = (e) => {
    if (!drawing) return
    e.preventDefault()
    const ctx = ref.current.getContext('2d')
    const { x, y } = pos(e); ctx.lineTo(x, y); ctx.stroke()
  }
  const end = () => {
    if (!drawing) return
    setDrawing(false)
    onChange(ref.current.toDataURL('image/png'))
  }

  return (
    <div>
      <canvas ref={ref} width={420} height={130}
        style={{ border: '1px dashed #bbb', background: '#fff', width: '100%', maxWidth: 420, touchAction: 'none' }}
        onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
        onTouchStart={start} onTouchMove={move} onTouchEnd={end} />
      <div>
        <button type="button" className="btn sm ghost" onClick={() => {
          const ctx = ref.current.getContext('2d')
          ctx.clearRect(0, 0, ref.current.width, ref.current.height); onChange('')
        }}>پاک کردن امضا</button>
        {value && <span className="hint"> امضا ثبت شد</span>}
      </div>
    </div>
  )
}
