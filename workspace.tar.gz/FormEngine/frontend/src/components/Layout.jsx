import React from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../App.jsx'
import { ROLE_FA } from '../api.js'

export default function Layout() {
  const { user, tenant, logout } = useAuth()
  const nav = useNavigate()
  const isAdmin = ['owner', 'admin'].includes(user?.role)

  const doLogout = async () => { await logout(); nav('/login') }

  return (
    <>
      <div className="topbar">
        <img src="/logo.png" alt="Formobile" />
        <div className="ws">🔒 فضای کاری: <b>{tenant?.name}</b> <span className="mono" style={{ color: '#888' }}>/{tenant?.slug}</span></div>
        <div className="spacer" />
        <div className="chip">
          <span className="avatar">{(user?.full_name || user?.username || '?').trim().charAt(0)}</span>
          {user?.full_name || user?.username} — <span style={{ color: 'var(--red)' }}>{ROLE_FA[user?.role]}</span>
          · <a href="#" onClick={(e) => { e.preventDefault(); doLogout() }}>خروج</a>
        </div>
      </div>
      <div className="nav">
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'on' : '')}>مسیرها و فرم‌ها</NavLink>
        {isAdmin && <NavLink to="/members" className={({ isActive }) => (isActive ? 'on' : '')}>اعضا</NavLink>}
        {isAdmin && <NavLink to="/audit" className={({ isActive }) => (isActive ? 'on' : '')}>گزارش رویدادها</NavLink>}
        <a href="/api/docs" target="_blank" rel="noreferrer">مستندات API</a>
      </div>
      <Outlet />
    </>
  )
}
