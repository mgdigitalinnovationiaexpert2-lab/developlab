import React, { useCallback, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api, STATUS_FA } from '../api.js'
import { useAuth } from '../App.jsx'
import FieldInput from '../components/FieldInput.jsx'

const PALETTE = [
  ['text', 'متن کوتاه'], ['textarea', 'متن بلند'], ['number', 'عدد / مبلغ'],
  ['national_id', 'کد ملی'], ['mobile', 'موبایل'], ['email', 'ایمیل'],
  ['date_jalali', 'تاریخ شمسی'], ['select', 'لیست کشویی'], ['radio', 'تک‌انتخابی'],
  ['checkbox', 'چندانتخابی'], ['file', 'آپلود فایل'], ['signature', 'امضا'],
  ['heading', 'عنوان / توضیح'], ['page_break', 'شکست صفحه'],
]
const LABELS = Object.fromEntries(PALETTE)
const NEEDS_OPTIONS = ['select', 'radio', 'checkbox']

export default function Builder() {
  const { id } = useParams()
  const { tenant } = useAuth()
  const [form, setForm] = useState(null)
  const [fields, setFields] = useState([])
  const [sel, setSel] = useState(-1)
  const [err, setErr] = useState('')
  const [ok, setOk] = useState('')
  const [over, setOver] = useState(false)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    try {
      const f = await api(`/forms/${id}`)
      setForm(f); setFields(f.schema.fields || [])
    } catch (e) { setErr(e.message) }
  }, [id])

  useEffect(() => { load() }, [load])

  const patch = (p) => setForm((f) => ({ ...f, ...p }))

  const addField = (type) => {
    const n = fields.length + 1
    let key = `field_${n}`
    while (fields.some((f) => f.key === key)) key = `field_${n}_${Math.floor(Math.random() * 90 + 10)}`
    const field = {
      id: `f${Date.now()}`, key, type, label: LABELS[type] || type,
      required: false, help: '', placeholder: '',
      options: NEEDS_OPTIONS.includes(type) ? ['گزینه ۱', 'گزینه ۲'] : [],
    }
    setFields([...fields, field]); setSel(fields.length); setOk('')
  }

  const updateSel = (p) => setFields((fs) => fs.map((f, i) => (i === sel ? { ...f, ...p } : f)))
  const move = (i, dir) => {
    const j = i + dir
    if (j < 0 || j >= fields.length) return
    const copy = [...fields];[copy[i], copy[j]] = [copy[j], copy[i]]
    setFields(copy); setSel(j)
  }
  const removeAt = (i) => { setFields(fields.filter((_, k) => k !== i)); setSel(-1) }

  const save = async (extra = {}) => {
    setErr(''); setOk(''); setBusy(true)
    try {
      const body = {
        title: form.title, description: form.description, slug: form.slug,
        public_enabled: form.public_enabled, require_login: form.require_login,
        one_per_user: form.one_per_user, status: form.status,
        schema: { title: form.title, fields }, ...extra,
      }
      const updated = await api(`/forms/${id}`, { method: 'PUT', body })
      setForm(updated); setFields(updated.schema.fields || [])
      setOk(`ذخیره شد — نسخهٔ ${updated.version}`)
    } catch (e) { setErr(e.message) } finally { setBusy(false) }
  }

  if (!form) return <div className="main">{err ? <div className="err">{err}</div> : 'در حال بارگذاری…'}</div>
  const current = fields[sel]

  return (
    <>
      <div className="bbar">
        <input className="inp" style={{ maxWidth: 280, fontWeight: 700 }} value={form.title}
          onChange={(e) => patch({ title: e.target.value })} />
        <span className="mono hint">v{form.version} · {STATUS_FA[form.status]}</span>
        <div className="spacer" />
        <Link className="btn sm ghost" to={`/forms/${id}/responses`}>پاسخ‌ها ({form.submissions})</Link>
        {form.public_enabled && form.status === 'published' && (
          <a className="btn sm ghost" href={`/f/${tenant?.slug}/${form.slug}`} target="_blank" rel="noreferrer">لینک عمومی</a>
        )}
        <button className="btn sm dark" disabled={busy} onClick={() => save()}>ذخیره</button>
        <button className="btn sm" disabled={busy}
          onClick={() => save({ status: form.status === 'published' ? 'draft' : 'published' })}>
          {form.status === 'published' ? 'بازگشت به پیش‌نویس' : 'انتشار'}
        </button>
        <Link className="btn sm ghost" to="/">بازگشت</Link>
      </div>

      {err && <div className="err" style={{ margin: 12 }}>{err}</div>}
      {ok && <div className="ok" style={{ margin: 12 }}>{ok}</div>}

      <div className="builder">
        <aside className="palette">
          <h3>اجزای فرم (بکشید یا کلیک کنید)</h3>
          {PALETTE.map(([type, label]) => (
            <div key={type} className="pitem" draggable
              onDragStart={(e) => e.dataTransfer.setData('text/field-type', type)}
              onClick={() => addField(type)}>⠿ {label}</div>
          ))}
        </aside>

        <div className="canvas">
          <div className="sheet">
            <h2>{form.title}</h2>
            <textarea className="inp" style={{ minHeight: 50, marginBottom: 14 }} value={form.description || ''}
              placeholder="توضیح بالای فرم…" onChange={(e) => patch({ description: e.target.value })} />

            {fields.map((f, i) => (
              <div key={f.id || i} className={`frow${sel === i ? ' sel' : ''}`} onClick={() => setSel(i)}>
                <div className="tools">
                  <button onClick={(e) => { e.stopPropagation(); move(i, -1) }} title="بالا">↑</button>
                  <button onClick={(e) => { e.stopPropagation(); move(i, 1) }} title="پایین">↓</button>
                  <button onClick={(e) => { e.stopPropagation(); removeAt(i) }} title="حذف">✕</button>
                </div>
                <FieldInput field={f} value={undefined} onChange={() => { }} />
                <div className="hint mono">{f.key} · {f.type}</div>
              </div>
            ))}

            <div className={`drop${over ? ' over' : ''}`}
              onDragOver={(e) => { e.preventDefault(); setOver(true) }}
              onDragLeave={() => setOver(false)}
              onDrop={(e) => {
                e.preventDefault(); setOver(false)
                const type = e.dataTransfer.getData('text/field-type')
                if (type) addField(type)
              }}>
              ＋ فیلد را اینجا رها کنید یا از ستون کنار انتخاب کنید
            </div>
          </div>
        </div>

        <aside className="props">
          <h3>ویژگی‌های فیلد</h3>
          {!current && <div className="hint">یک فیلد را در وسط صفحه انتخاب کنید.</div>}
          {current && (
            <>
              <div className="field"><label>برچسب</label>
                <input className="inp" value={current.label} onChange={(e) => updateSel({ label: e.target.value })} /></div>
              <div className="field"><label>نام فنی (کلید لاتین)</label>
                <input className="inp mono" value={current.key} onChange={(e) => updateSel({ key: e.target.value })} /></div>
              <div className="field"><label>نوع</label>
                <select className="inp" value={current.type} onChange={(e) => {
                  const type = e.target.value
                  updateSel({ type, options: NEEDS_OPTIONS.includes(type) ? (current.options?.length ? current.options : ['گزینه ۱', 'گزینه ۲']) : [] })
                }}>{PALETTE.map(([t, l]) => <option key={t} value={t}>{l}</option>)}</select></div>
              <div className="field"><label>متن راهنما</label>
                <input className="inp" value={current.help || ''} onChange={(e) => updateSel({ help: e.target.value })} /></div>
              <div className="field"><label>متن داخل کادر</label>
                <input className="inp" value={current.placeholder || ''} onChange={(e) => updateSel({ placeholder: e.target.value })} /></div>
              {NEEDS_OPTIONS.includes(current.type) && (
                <div className="field"><label>گزینه‌ها (هر خط یک گزینه)</label>
                  <textarea className="inp" value={(current.options || []).join('\n')}
                    onChange={(e) => updateSel({ options: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean) })} /></div>
              )}
              {['text', 'textarea', 'number'].includes(current.type) && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <div className="field" style={{ flex: 1 }}><label>حداقل</label>
                    <input className="inp mono" value={current.min ?? ''} onChange={(e) => updateSel({ min: e.target.value === '' ? null : Number(e.target.value) })} /></div>
                  <div className="field" style={{ flex: 1 }}><label>حداکثر</label>
                    <input className="inp mono" value={current.max ?? ''} onChange={(e) => updateSel({ max: e.target.value === '' ? null : Number(e.target.value) })} /></div>
                </div>
              )}
              <label className="switch"><input type="checkbox" checked={!!current.required} onChange={(e) => updateSel({ required: e.target.checked })} /> الزامی</label>
              <label className="switch"><input type="checkbox" checked={!!current.unique} onChange={(e) => updateSel({ unique: e.target.checked })} /> یکتا در همین فرم</label>
              <div className="field" style={{ marginTop: 10 }}>
                <label>نمایش شرطی: اگر فیلد…</label>
                <input className="inp mono" placeholder="کلید فیلد مرجع" value={current.visible_when?.key || ''}
                  onChange={(e) => updateSel({ visible_when: e.target.value ? { key: e.target.value, equals: current.visible_when?.equals || '' } : null })} />
                <input className="inp" style={{ marginTop: 6 }} placeholder="برابر با این مقدار" value={current.visible_when?.equals || ''}
                  onChange={(e) => updateSel({ visible_when: { key: current.visible_when?.key || '', equals: e.target.value } })} />
              </div>
            </>
          )}

          <div style={{ borderTop: '1px dashed var(--line)', margin: '14px 0 10px' }} />
          <h3>دسترسی و انتشار</h3>
          <div className="field"><label>اسلاگ لینک عمومی</label>
            <input className="inp mono" value={form.slug} onChange={(e) => patch({ slug: e.target.value })} /></div>
          <label className="switch"><input type="checkbox" checked={form.public_enabled} onChange={(e) => patch({ public_enabled: e.target.checked })} /> لینک عمومی فعال</label>
          <label className="switch"><input type="checkbox" checked={form.require_login} onChange={(e) => patch({ require_login: e.target.checked })} /> فقط کاربران واردشده</label>
          <label className="switch"><input type="checkbox" checked={form.one_per_user} onChange={(e) => patch({ one_per_user: e.target.checked })} /> هر کاربر یک پاسخ</label>
          <div className="field"><label>وضعیت</label>
            <select className="inp" value={form.status} onChange={(e) => patch({ status: e.target.value })}>
              <option value="draft">پیش‌نویس</option><option value="published">منتشرشده</option><option value="closed">بسته</option>
            </select></div>
          <button className="btn sm block" disabled={busy} onClick={() => save()}>اعمال و ذخیره</button>
        </aside>
      </div>
    </>
  )
}
