import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api, ROLE_FA } from '../api.js'

export default function Invite() {
  const { token } = useParams()
  const nav = useNavigate()
  const [info, setInfo] = useState(null)
  const [err, setErr] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [done, setDone] = useState(false)

  useEffect(() => {
    api(`/auth/invite/${token}`).then((d) => { setInfo(d); setFullName(d.full_name || '') })
      .catch((e) => setErr(e.message))
  }, [token])

  const submit = async (e) => {
    e.preventDefault(); setErr('')
    try {
      await api('/auth/invite/accept', { method: 'POST', body: { token, password, full_name: fullName } })
      setDone(true)
      setTimeout(() => nav('/login'), 1500)
    } catch (e2) { setErr(e2.message) }
  }

  return (
    <div className="login-wrap">
      <img className="logo-big" src="/logo.png" alt="Formobile" />
      <div className="pencil">دعوت‌نامهٔ عضویت</div>
      <div className="card">
        {err && <div className="err">{err}</div>}
        {done && <div className="ok">حساب شما ساخته شد؛ در حال انتقال به صفحهٔ ورود…</div>}
        {info && !done && (
          <form onSubmit={submit}>
            <h2>تکمیل عضویت</h2>
            <p className="sub">
              فضای کاری <b>{info.tenant.name}</b> · نام کاربری <span className="mono">{info.username}</span> · نقش {ROLE_FA[info.role]}
            </p>
            <div className="field">
              <label>نام و نام خانوادگی</label>
              <input className="inp" value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="field">
              <label>رمز عبور (حداقل ۸ نویسه)</label>
              <input className="inp mono" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <button className="btn block" disabled={password.length < 8}>ساخت حساب</button>
          </form>
        )}
        {!info && !err && <div className="hint">در حال بررسی دعوت‌نامه…</div>}
      </div>
      <div className="footer-nav"><a href="/login">بازگشت به ورود</a></div>
    </div>
  )
}
