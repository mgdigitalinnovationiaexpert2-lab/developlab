import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import { useAuth } from '../App.jsx'

export default function ChangePassword() {
  const { user, refresh } = useAuth()
  const nav = useNavigate()
  const [cur, setCur] = useState('')
  const [next, setNext] = useState('')
  const [err, setErr] = useState('')
  const [ok, setOk] = useState('')

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setOk('')
    try {
      const r = await api('/auth/change-password', { method: 'POST', body: { current_password: cur, new_password: next } })
      setOk(r.message)
      await refresh()
      setTimeout(() => nav('/login'), 1200)
    } catch (e2) { setErr(e2.message) }
  }

  return (
    <div className="login-wrap">
      <img className="logo-big" src="/logo.png" alt="Formobile" />
      <div className="pencil">تغییر رمز عبور</div>
      <form className="card" onSubmit={submit}>
        <h2>رمز عبور جدید</h2>
        <p className="sub">
          {user?.must_change_password ? 'برای اولین ورود باید رمز اولیه را تغییر دهید.' : 'رمز فعلی و رمز جدید را وارد کنید.'}
        </p>
        {err && <div className="err">{err}</div>}
        {ok && <div className="ok">{ok}</div>}
        <div className="field">
          <label>رمز فعلی</label>
          <input className="inp mono" type="password" value={cur} onChange={(e) => setCur(e.target.value)} />
        </div>
        <div className="field">
          <label>رمز جدید (حداقل ۸ نویسه)</label>
          <input className="inp mono" type="password" value={next} onChange={(e) => setNext(e.target.value)} />
        </div>
        <button className="btn block" disabled={next.length < 8 || !cur}>تغییر رمز</button>
      </form>
      <div className="footer-nav"><a href="/">بازگشت</a></div>
    </div>
  )
}
