import React, { useCallback, useEffect, useState } from 'react'
import { api, faDate, ROLE_FA } from '../api.js'
import { useAuth } from '../App.jsx'

export default function Members() {
  const { user } = useAuth()
  const [members, setMembers] = useState([])
  const [invites, setInvites] = useState([])
  const [err, setErr] = useState('')
  const [ok, setOk] = useState('')
  const [form, setForm] = useState({ username: '', full_name: '', email: '', role: 'editor', mode: 'invite', password: '' })

  const load = useCallback(async () => {
    try {
      const [m, i] = await Promise.all([api('/users'), api('/users/invites/list')])
      setMembers(m); setInvites(i)
    } catch (e) { setErr(e.message) }
  }, [])

  useEffect(() => { load() }, [load])
  const patch = (p) => setForm((f) => ({ ...f, ...p }))

  const create = async (e) => {
    e.preventDefault(); setErr(''); setOk('')
    try {
      const body = { ...form, email: form.email || null, password: form.mode === 'direct' ? form.password : null }
      const r = await api('/users', { method: 'POST', body })
      if (r.invite) {
        const link = `${window.location.origin}${r.invite.link}`
        setOk(`دعوت‌نامه ساخته شد — این لینک را برای عضو بفرستید: ${link}`)
      } else {
        setOk(`عضو «${r.user.username}» ساخته شد. در اولین ورود باید رمز را تغییر دهد.`)
      }
      setForm({ username: '', full_name: '', email: '', role: 'editor', mode: 'invite', password: '' })
      await load()
    } catch (e2) { setErr(e2.message) }
  }

  const changeRole = async (m, role) => {
    setErr(''); setOk('')
    try { await api(`/users/${m.id}`, { method: 'PATCH', body: { role } }); await load() } catch (e) { setErr(e.message) }
  }
  const toggleActive = async (m) => {
    setErr(''); setOk('')
    try {
      if (m.is_active) {
        if (!confirm(`«${m.full_name || m.username}» غیرفعال شود؟ دسترسی او فوراً قطع و فرم‌هایش به شما منتقل می‌شود.`)) return
        await api(`/users/${m.id}`, { method: 'DELETE' })
      } else {
        await api(`/users/${m.id}`, { method: 'PATCH', body: { is_active: true } })
      }
      await load()
    } catch (e) { setErr(e.message) }
  }
  const resetPassword = async (m) => {
    if (!confirm(`رمز «${m.full_name || m.username}» بازنشانی شود؟`)) return
    try {
      const r = await api(`/users/${m.id}/reset-password`, { method: 'POST' })
      setOk(`رمز موقت ${m.username}: ${r.temporary_password} — در اولین ورود باید تغییر کند.`)
    } catch (e) { setErr(e.message) }
  }
  const revokeInvite = async (i) => {
    try { await api(`/users/invites/${i.id}`, { method: 'DELETE' }); await load() } catch (e) { setErr(e.message) }
  }

  return (
    <main className="main">
      <h1 className="title">اعضای فضای کاری</h1>
      <p className="lead">افزودن عضو فقط توسط مدیر همین فضای کاری انجام می‌شود. عضو جدید به مسیرهای دیگران دسترسی ندارد مگر صریحاً اجازه داده شود.</p>
      {err && <div className="err">{err}</div>}
      {ok && <div className="ok" style={{ wordBreak: 'break-all' }}>{ok}</div>}

      <div className="grid2">
        <form className="panel" onSubmit={create}>
          <h4>افزودن عضو جدید</h4>
          <div className="field"><label>نام کاربری (لاتین)</label>
            <input className="inp mono" value={form.username} onChange={(e) => patch({ username: e.target.value })} placeholder="maryam" /></div>
          <div className="field"><label>نام و نام خانوادگی</label>
            <input className="inp" value={form.full_name} onChange={(e) => patch({ full_name: e.target.value })} /></div>
          <div className="field"><label>ایمیل (اختیاری)</label>
            <input className="inp mono" value={form.email} onChange={(e) => patch({ email: e.target.value })} /></div>
          <div className="field"><label>نقش</label>
            <select className="inp" value={form.role} onChange={(e) => patch({ role: e.target.value })}>
              <option value="editor">سازندهٔ فرم</option><option value="viewer">بینندهٔ پاسخ‌ها</option><option value="admin">مدیر فضای کاری</option>
            </select></div>
          <div className="field"><label>روش افزودن</label>
            <select className="inp" value={form.mode} onChange={(e) => patch({ mode: e.target.value })}>
              <option value="invite">دعوت‌نامهٔ یک‌بارمصرف (۷۲ ساعت)</option>
              <option value="direct">ساخت مستقیم با رمز موقت</option>
            </select></div>
          {form.mode === 'direct' && (
            <div className="field"><label>رمز اولیه (حداقل ۸ نویسه)</label>
              <input className="inp mono" value={form.password} onChange={(e) => patch({ password: e.target.value })} /></div>
          )}
          <button className="btn sm block" disabled={form.username.length < 2 || (form.mode === 'direct' && form.password.length < 8)}>
            {form.mode === 'invite' ? 'ساخت دعوت‌نامه' : 'ساخت عضو'}
          </button>
        </form>

        <div className="panel">
          <h4>سیاست‌های امنیتی این فضا</h4>
          <div className="kv"><span>ثبت‌نام عمومی</span><span className="tag red">غیرفعال</span></div>
          <div className="kv"><span>الگوریتم رمز</span><span className="mono">Argon2id</span></div>
          <div className="kv"><span>قفل حساب پس از تلاش ناموفق</span><span className="mono">5 / 15min</span></div>
          <div className="kv"><span>نشست</span><span className="mono">HttpOnly cookie + session revoke</span></div>
          <div className="kv"><span>جداسازی داده</span><span className="mono">TenantId + Path ACL</span></div>
          <div className="kv"><span>دانلود فایل</span><span className="mono">signed URL · 60s</span></div>
          <div className="kv"><span>گزارش رویدادها</span><span className="tag green">فعال</span></div>
          <div className="hint" style={{ marginTop: 10 }}>مقادیر از <span className="mono">backend/app/core/config.py</span> خوانده می‌شوند.</div>
        </div>
      </div>

      <h4 style={{ margin: '18px 0 8px', fontSize: 13.5 }}>فهرست اعضا</h4>
      <table>
        <thead><tr><th>عضو</th><th style={{ width: 150 }}>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th style={{ width: 230 }}>عملیات</th></tr></thead>
        <tbody>
          {members.map((m) => (
            <tr key={m.id}>
              <td>{m.full_name || m.username} · <span className="mono hint">{m.username}</span></td>
              <td>
                {m.id === user.id || m.role === 'owner'
                  ? <span className="tag red">{ROLE_FA[m.role]}</span>
                  : <select className="inp" value={m.role} onChange={(e) => changeRole(m, e.target.value)}>
                      <option value="editor">سازنده</option><option value="viewer">بیننده</option><option value="admin">مدیر</option>
                    </select>}
              </td>
              <td><span className={`tag ${m.is_active ? 'green' : 'gray'}`}>{m.is_active ? 'فعال' : 'غیرفعال'}</span></td>
              <td>{faDate(m.last_login_at)}</td>
              <td>
                {m.role !== 'owner' && m.id !== user.id && <>
                  <a href="#" onClick={(e) => { e.preventDefault(); toggleActive(m) }}>{m.is_active ? 'غیرفعال‌سازی' : 'فعال‌سازی'}</a> · {' '}
                  <a href="#" onClick={(e) => { e.preventDefault(); resetPassword(m) }}>بازنشانی رمز</a>
                </>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h4 style={{ margin: '20px 0 8px', fontSize: 13.5 }}>دعوت‌نامه‌های در انتظار</h4>
      <table>
        <thead><tr><th>نام کاربری</th><th>نقش</th><th>انقضا</th><th style={{ width: 100 }}>عملیات</th></tr></thead>
        <tbody>
          {invites.map((i) => (
            <tr key={i.id}>
              <td className="mono">{i.username}</td><td>{ROLE_FA[i.role]}</td>
              <td>{faDate(i.expires_at)} {i.expired && <span className="tag red">منقضی</span>}</td>
              <td><a href="#" onClick={(e) => { e.preventDefault(); revokeInvite(i) }}>لغو</a></td>
            </tr>
          ))}
          {invites.length === 0 && <tr><td colSpan={4} className="hint">دعوت‌نامه‌ای در انتظار نیست.</td></tr>}
        </tbody>
      </table>
    </main>
  )
}
