import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import { useAuth } from '../App.jsx'

export default function Login() {
  const { setUser, setTenant, user } = useAuth()
  const nav = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  React.useEffect(() => { if (user) nav('/', { replace: true }) }, [user, nav])

  const submit = async (e) => {
    e.preventDefault()
    setErr(''); setBusy(true)
    try {
      const data = await api('/auth/login', { method: 'POST', body: { username, password } })
      setUser(data.user); setTenant(data.tenant)
      nav(data.user.must_change_password ? '/change-password' : '/', { replace: true })
    } catch (e2) { setErr(e2.message) } finally { setBusy(false) }
  }

  return (
    <div className="login-wrap">
      <img className="logo-big" src="/logo.png" alt="Formobile" />
      <div className="pencil">…برداشتن همهٔ موانع از سر راهِ فرم‌ها</div>

      <form className="card" onSubmit={submit}>
        <h2>ورود به فضای کاری</h2>
        <p className="sub">نام کاربری و رمز عبور را وارد کنید.</p>
        {err && <div className="err">{err}</div>}
        <div className="field">
          <label>نام کاربری یا ایمیل</label>
          <input className="inp mono" value={username} autoComplete="username"
            onChange={(e) => setUsername(e.target.value)} placeholder="farzad" />
        </div>
        <div className="field">
          <label>رمز عبور</label>
          <input className="inp mono" type="password" value={password} autoComplete="current-password"
            onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </div>
        <button className="btn block" disabled={busy}>{busy ? 'در حال ورود…' : '🔑 ورود'}</button>
        <div className="note">
          🔒 ثبت‌نام عمومی غیرفعال است. هر عضو را <b>مدیر همان فضای کاری</b> اضافه می‌کند.
          <div style={{ marginTop: 8 }}>
            حساب‌های نمونه: <span className="mono">farzad/farzad1234</span> ·{' '}
            <span className="mono">maryam/maryam1234</span> · <span className="mono">ali/ali1234</span>
            <br />فضای کاری دیگر: <span className="mono">reza/reza1234</span>
          </div>
        </div>
      </form>

      <div className="footer-nav">
        <a href="/api/docs" target="_blank" rel="noreferrer">مستندات API</a>
        <a href="#" onClick={(e) => e.preventDefault()}>راهنما</a>
        <a href="#" onClick={(e) => e.preventDefault()}>امنیت و حریم خصوصی</a>
        <a href="#" onClick={(e) => e.preventDefault()}>پشتیبانی</a>
      </div>
    </div>
  )
}
