import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api, faDate, PERM_FA, ROLE_FA, STATUS_FA, VIS_FA } from '../api.js'
import { useAuth } from '../App.jsx'

export default function Workspace() {
  const { user, tenant } = useAuth()
  const nav = useNavigate()
  const [paths, setPaths] = useState([])
  const [forms, setForms] = useState([])
  const [members, setMembers] = useState([])
  const [sel, setSel] = useState(null)
  const [newPath, setNewPath] = useState('')
  const [parentForNew, setParentForNew] = useState('')
  const [newForm, setNewForm] = useState('')
  const [err, setErr] = useState('')
  const [sharePath, setSharePath] = useState(null)

  const load = useCallback(async () => {
    setErr('')
    try {
      const [p, f, m] = await Promise.all([api('/paths'), api('/forms'), api('/users')])
      setPaths(p); setForms(f); setMembers(m)
      setSel((cur) => (cur && p.some((x) => x.id === cur) ? cur : (p[0]?.id ?? null)))
    } catch (e) { setErr(e.message) }
  }, [])

  useEffect(() => { load() }, [load])

  const byParent = useMemo(() => {
    const map = {}
    paths.forEach((p) => { const k = p.parent_id || 'root'; (map[k] = map[k] || []).push(p) })
    return map
  }, [paths])

  const selected = paths.find((p) => p.id === sel) || null
  const shownForms = sel ? forms.filter((f) => f.path_id === sel) : forms
  const writable = paths.filter((p) => ['write', 'manage'].includes(p.permission))

  const createPath = async (e) => {
    e.preventDefault(); setErr('')
    try {
      const p = await api('/paths', { method: 'POST', body: { name: newPath, parent_id: parentForNew || null } })
      setNewPath(''); await load(); setSel(p.id)
    } catch (e2) { setErr(e2.message) }
  }

  const removePath = async (p) => {
    if (!confirm(`مسیر «${p.name}» و همهٔ زیرمسیرها، فرم‌ها و فایل‌هایش حذف شود؟`)) return
    try { await api(`/paths/${p.id}`, { method: 'DELETE' }); setSel(null); await load() }
    catch (e) { setErr(e.message) }
  }

  const createForm = async (e) => {
    e.preventDefault(); setErr('')
    if (!sel) { setErr('اول یک مسیر انتخاب یا ایجاد کنید'); return }
    try {
      const f = await api('/forms', { method: 'POST', body: { path_id: sel, title: newForm } })
      setNewForm(''); nav(`/forms/${f.id}/edit`)
    } catch (e2) { setErr(e2.message) }
  }

  const removeForm = async (f) => {
    if (!confirm(`فرم «${f.title}» و پاسخ‌هایش حذف شود؟`)) return
    try { await api(`/forms/${f.id}`, { method: 'DELETE' }); await load() } catch (e) { setErr(e.message) }
  }

  const renderTree = (key = 'root', depth = 0) => (byParent[key] || []).map((p) => (
    <React.Fragment key={p.id}>
      <div className={`node${sel === p.id ? ' on' : ''}`} style={{ paddingInlineStart: 6 + depth * 16 }}
        onClick={() => setSel(p.id)}>
        <span>📁</span>
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
        {p.visibility === 'private' && <span className="lock">🔒</span>}
        <span className="cnt">{forms.filter((f) => f.path_id === p.id).length}</span>
      </div>
      {renderTree(p.id, depth + 1)}
    </React.Fragment>
  ))

  return (
    <div className="layout">
      <aside className="side">
        <h3>مسیرهای من</h3>
        {renderTree()}
        {paths.length === 0 && <div className="hint">هنوز مسیری ندارید.</div>}
        <div className="hint" style={{ marginTop: 10, borderTop: '1px dashed var(--line)', paddingTop: 8 }}>
          🔒 مسیرهای خصوصی دیگر اعضا اینجا نمایش داده نمی‌شود.
        </div>

        <form onSubmit={createPath} style={{ marginTop: 12, borderTop: '1px dashed var(--line)', paddingTop: 12 }}>
          <div className="field">
            <label>نام مسیر جدید</label>
            <input className="inp" value={newPath} onChange={(e) => setNewPath(e.target.value)} placeholder="مثلاً ثبت‌نام دوره‌ها" />
          </div>
          <div className="field">
            <label>زیرمجموعهٔ</label>
            <select className="inp" value={parentForNew} onChange={(e) => setParentForNew(e.target.value)}>
              <option value="">— ریشه —</option>
              {writable.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <button className="btn sm block" disabled={!newPath.trim()}>＋ ساخت مسیر</button>
        </form>
      </aside>

      <main className="main">
        {err && <div className="err">{err}</div>}
        <div className="crumb">/{tenant?.slug}/{selected ? selected.slug : ''}</div>
        <h1 className="title">{selected ? selected.name : 'همهٔ فرم‌های قابل دسترس'}</h1>
        <p className="lead">
          {selected ? <>مالک: <b>{members.find((m) => m.id === selected.owner_id)?.full_name || '—'}</b> · سطح دسترسی: {VIS_FA[selected.visibility]} · اجازهٔ شما: {PERM_FA[selected.permission]}</> : 'مسیری را از ستون کنار انتخاب کنید.'}
        </p>

        <div className="toolbar">
          <form onSubmit={createForm} style={{ display: 'flex', gap: 8 }}>
            <input className="inp" style={{ minWidth: 200 }} value={newForm}
              onChange={(e) => setNewForm(e.target.value)} placeholder="نام فرم جدید…" />
            <button className="btn sm" disabled={!newForm.trim() || !selected || !['write', 'manage'].includes(selected?.permission)}>＋ فرم جدید</button>
          </form>
          {selected && selected.permission === 'manage' && (
            <>
              <button className="btn sm ghost" onClick={() => setSharePath(selected)}>اشتراک‌گذاری مسیر</button>
              <button className="btn sm ghost" onClick={() => removePath(selected)}>حذف مسیر</button>
            </>
          )}
          <div className="spacer" />
          <button className="btn sm ghost" onClick={load}>بروزرسانی</button>
        </div>

        <table>
          <thead>
            <tr><th style={{ width: '28%' }}>نام فرم</th><th>وضعیت</th><th>پاسخ‌ها</th><th>آخرین تغییر</th><th>لینک عمومی</th><th style={{ width: '18%' }}>عملیات</th></tr>
          </thead>
          <tbody>
            {shownForms.map((f) => (
              <tr key={f.id}>
                <td>{f.title}</td>
                <td><span className={`tag ${f.status === 'published' ? 'green' : f.status === 'closed' ? 'red' : 'gray'}`}>{STATUS_FA[f.status]}</span></td>
                <td className="mono">{f.submissions}</td>
                <td>{faDate(f.updated_at)}</td>
                <td className="mono">
                  {f.public_enabled && f.status === 'published'
                    ? <a href={`/f/${tenant?.slug}/${f.slug}`} target="_blank" rel="noreferrer">/f/{tenant?.slug}/{f.slug}</a>
                    : '—'}
                </td>
                <td>
                  <Link to={`/forms/${f.id}/edit`}>ویرایش</Link> · <Link to={`/forms/${f.id}/responses`}>پاسخ‌ها</Link>
                  {selected?.permission === 'manage' && <> · <a href="#" onClick={(e) => { e.preventDefault(); removeForm(f) }}>حذف</a></>}
                </td>
              </tr>
            ))}
            {shownForms.length === 0 && <tr><td colSpan={6} className="hint">فرمی در این مسیر نیست.</td></tr>}
          </tbody>
        </table>

        <div className="callout">
          <b>قاعدهٔ جداسازی:</b> هر فرم، پاسخ و فایل به <span className="mono">TenantId + PathId + OwnerId</span> گره خورده است.
          درخواست کاربر دیگر — حتی با داشتن شناسهٔ فایل یا لینک مستقیم — با <span className="mono">404</span> پاسخ می‌گیرد
          (نه <span className="mono">403</span>، تا وجود منبع هم فاش نشود).
        </div>

        <div className="grid2">
          <div className="panel">
            <h4>اعضای این فضای کاری</h4>
            {members.map((m) => (
              <div className="kv" key={m.id}>
                <span>{m.full_name || m.username} <span className="mono hint">({m.username})</span></span>
                <span className={`tag ${m.role === 'owner' || m.role === 'admin' ? 'red' : ''}`}>{ROLE_FA[m.role]}{m.is_active ? '' : ' · غیرفعال'}</span>
              </div>
            ))}
          </div>
          <div className="panel">
            <h4>وضعیت فضا</h4>
            <div className="kv"><span>مسیرهای قابل دسترس</span><span className="mono">{paths.length}</span></div>
            <div className="kv"><span>فرم‌های قابل دسترس</span><span className="mono">{forms.length}</span></div>
            <div className="kv"><span>مجموع پاسخ‌ها</span><span className="mono">{forms.reduce((s, f) => s + f.submissions, 0)}</span></div>
            <div className="kv"><span>مدیر مسیرهای خصوصی دیگران را می‌بیند؟</span><span className="tag">{tenant?.admin_can_view_private_paths ? 'بله' : 'خیر'}</span></div>
          </div>
        </div>
      </main>

      {sharePath && <ShareModal path={sharePath} members={members} onClose={() => { setSharePath(null); load() }} />}
    </div>
  )
}

function ShareModal({ path, members, onClose }) {
  const [grants, setGrants] = useState([])
  const [userId, setUserId] = useState('')
  const [perm, setPerm] = useState('read')
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    try { setGrants(await api(`/paths/${path.id}/permissions`)) } catch (e) { setErr(e.message) }
  }, [path.id])

  useEffect(() => { load() }, [load])

  const grant = async () => {
    setErr('')
    try { await api(`/paths/${path.id}/permissions`, { method: 'PUT', body: { user_id: userId, permission: perm } }); setUserId(''); await load() }
    catch (e) { setErr(e.message) }
  }
  const revoke = async (uid) => {
    try { await api(`/paths/${path.id}/permissions/${uid}`, { method: 'DELETE' }); await load() } catch (e) { setErr(e.message) }
  }

  const candidates = members.filter((m) => m.is_active && m.id !== path.owner_id)

  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3>اشتراک‌گذاری مسیر «{path.name}»</h3>
        {err && <div className="err">{err}</div>}
        <div className="field">
          <label>عضو</label>
          <select className="inp" value={userId} onChange={(e) => setUserId(e.target.value)}>
            <option value="">— انتخاب عضو —</option>
            {candidates.map((m) => <option key={m.id} value={m.id}>{m.full_name || m.username} ({m.username})</option>)}
          </select>
        </div>
        <div className="field">
          <label>سطح دسترسی</label>
          <select className="inp" value={perm} onChange={(e) => setPerm(e.target.value)}>
            <option value="read">فقط مشاهده (فرم‌ها و پاسخ‌ها)</option>
            <option value="write">ویرایش و ساخت فرم</option>
            <option value="manage">مدیریت کامل (شامل اشتراک‌گذاری و حذف)</option>
          </select>
        </div>
        <button className="btn sm" disabled={!userId} onClick={grant}>اعمال دسترسی</button>

        <h4 style={{ margin: '18px 0 8px', fontSize: 13 }}>دسترسی‌های فعلی</h4>
        {grants.length === 0 && <div className="hint">این مسیر با کسی به اشتراک گذاشته نشده است.</div>}
        {grants.map((g) => (
          <div className="kv" key={g.user_id}>
            <span>{g.full_name || g.username}</span>
            <span>
              <span className="tag">{PERM_FA[g.permission]}</span>{' '}
              <a href="#" onClick={(e) => { e.preventDefault(); revoke(g.user_id) }}>لغو</a>
            </span>
          </div>
        ))}
        <div className="hint" style={{ marginTop: 12 }}>دسترسی به زیرمسیرها ارث می‌رسد؛ با لغو آن، دسترسی زیرمسیرها هم قطع می‌شود.</div>
        <div style={{ marginTop: 14, textAlign: 'left' }}><button className="btn sm dark" onClick={onClose}>بستن</button></div>
      </div>
    </div>
  )
}
