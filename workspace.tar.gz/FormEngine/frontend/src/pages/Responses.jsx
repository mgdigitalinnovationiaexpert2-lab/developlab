import React, { useCallback, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api, faDate } from '../api.js'

export default function Responses() {
  const { id } = useParams()
  const [form, setForm] = useState(null)
  const [schema, setSchema] = useState({ fields: [] })
  const [items, setItems] = useState([])
  const [err, setErr] = useState('')
  const [detail, setDetail] = useState(null)

  const load = useCallback(async () => {
    try {
      const [f, s] = await Promise.all([api(`/forms/${id}`), api(`/forms/${id}/submissions`)])
      setForm(f); setSchema(s.schema); setItems(s.items)
    } catch (e) { setErr(e.message) }
  }, [id])

  useEffect(() => { load() }, [load])

  const cols = (schema.fields || []).filter((f) => !['heading', 'page_break', 'signature'].includes(f.type))

  const remove = async (sid) => {
    if (!confirm('این پاسخ حذف شود؟')) return
    try { await api(`/submissions/${sid}`, { method: 'DELETE' }); await load() } catch (e) { setErr(e.message) }
  }

  const cell = (f, data) => {
    const v = data[f.key]
    if (v === undefined || v === null || v === '') return '—'
    if (Array.isArray(v)) {
      if (f.type === 'file') return v.map((fid) => (
        <a key={fid} href={`/api/v1/files/${fid}/download`} target="_blank" rel="noreferrer">دانلود فایل</a>
      ))
      return v.join(' | ')
    }
    return String(v)
  }

  return (
    <main className="main">
      {err && <div className="err">{err}</div>}
      <h1 className="title">پاسخ‌های {form?.title || ''}</h1>
      <p className="lead">فقط پاسخ‌های همین فرم در مسیرهای مجاز شما نمایش داده می‌شود.</p>
      <div className="toolbar">
        <Link className="btn sm ghost" to={`/forms/${id}/edit`}>ویرایش فرم</Link>
        <a className="btn sm ghost" href={`/api/v1/forms/${id}/submissions.csv`}>خروجی CSV / Excel</a>
        <button className="btn sm ghost" onClick={load}>بروزرسانی</button>
        <div className="spacer" />
        <span className="hint">{items.length} پاسخ</span>
      </div>

      <table>
        <thead>
          <tr><th style={{ width: 40 }}>#</th><th>تاریخ ثبت</th>{cols.map((f) => <th key={f.key}>{f.label || f.key}</th>)}<th style={{ width: 110 }}>عملیات</th></tr>
        </thead>
        <tbody>
          {items.map((s, i) => (
            <tr key={s.id}>
              <td className="mono">{i + 1}</td>
              <td>{faDate(s.created_at)}</td>
              {cols.map((f) => <td key={f.key}>{cell(f, s.data)}</td>)}
              <td><a href="#" onClick={(e) => { e.preventDefault(); setDetail(s) }}>جزئیات</a> · <a href="#" onClick={(e) => { e.preventDefault(); remove(s.id) }}>حذف</a></td>
            </tr>
          ))}
          {items.length === 0 && <tr><td colSpan={cols.length + 3} className="hint">پاسخی ثبت نشده است.</td></tr>}
        </tbody>
      </table>

      {detail && (
        <div className="modal-bg" onClick={() => setDetail(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>جزئیات پاسخ</h3>
            <div className="hint">شناسه: <span className="mono">{detail.id}</span> · {faDate(detail.created_at)} · IP: <span className="mono">{detail.ip || '—'}</span></div>
            {(schema.fields || []).filter((f) => !['heading', 'page_break'].includes(f.type)).map((f) => (
              <div className="kv" key={f.key}><span>{f.label || f.key}</span><span>{cell(f, detail.data)}</span></div>
            ))}
            {detail.data && Object.entries(detail.data).filter(([k]) => k.startsWith('sign')).map(([k, v]) => (
              <img key={k} src={v} alt="امضا" style={{ maxWidth: '100%', border: '1px solid var(--line)' }} />
            ))}
            <div style={{ marginTop: 14, textAlign: 'left' }}><button className="btn sm dark" onClick={() => setDetail(null)}>بستن</button></div>
          </div>
        </div>
      )}
    </main>
  )
}
