import React, { useEffect, useState } from 'react'
import { api, faDate } from '../api.js'

const ACTION_FA = {
  'login.success': 'ورود موفق', 'login.failed': 'تلاش ناموفق ورود', 'logout': 'خروج',
  'account.locked': 'قفل حساب', 'password.changed': 'تغییر رمز',
  'member.created': 'ساخت عضو', 'member.invited': 'دعوت عضو', 'member.updated': 'ویرایش عضو',
  'member.deactivated': 'غیرفعال‌سازی عضو', 'member.password_reset': 'بازنشانی رمز عضو',
  'invite.accepted': 'پذیرش دعوت', 'invite.revoked': 'لغو دعوت',
  'path.created': 'ساخت مسیر', 'path.updated': 'ویرایش مسیر', 'path.deleted': 'حذف مسیر',
  'path.shared': 'اشتراک مسیر', 'path.unshared': 'لغو اشتراک مسیر',
  'form.created': 'ساخت فرم', 'form.updated': 'ویرایش فرم', 'form.deleted': 'حذف فرم',
  'submission.created': 'ثبت پاسخ', 'submission.deleted': 'حذف پاسخ', 'submission.exported': 'خروجی گرفتن',
  'file.uploaded': 'آپلود فایل', 'file.downloaded': 'دانلود فایل', 'file.deleted': 'حذف فایل',
  'file.link_issued': 'صدور لینک دانلود',
}

export default function Audit() {
  const [rows, setRows] = useState([])
  const [err, setErr] = useState('')

  const load = () => api('/audit?limit=200').then(setRows).catch((e) => setErr(e.message))
  useEffect(() => { load() }, [])

  return (
    <main className="main">
      <h1 className="title">گزارش رویدادها</h1>
      <p className="lead">همهٔ رویدادهای امنیتی و محتوایی همین فضای کاری — قابل مشاهده فقط برای مدیر.</p>
      {err && <div className="err">{err}</div>}
      <div className="toolbar"><button className="btn sm ghost" onClick={load}>بروزرسانی</button></div>
      <table>
        <thead><tr><th style={{ width: 170 }}>زمان</th><th>رویداد</th><th>کاربر</th><th>موجودیت</th><th>IP</th><th>جزئیات</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{faDate(r.at)}</td>
              <td>{ACTION_FA[r.action] || r.action}</td>
              <td className="mono">{r.user}</td>
              <td className="hint">{r.entity_type}</td>
              <td className="mono">{r.ip || '—'}</td>
              <td className="hint mono" style={{ maxWidth: 320, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {Object.keys(r.meta || {}).length ? JSON.stringify(r.meta) : '—'}
              </td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td colSpan={6} className="hint">رویدادی ثبت نشده است.</td></tr>}
        </tbody>
      </table>
    </main>
  )
}
