import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../api.js'
import FieldInput from '../components/FieldInput.jsx'

export default function PublicForm() {
  const { tenantSlug, formSlug } = useParams()
  const [form, setForm] = useState(null)
  const [data, setData] = useState({})
  const [errors, setErrors] = useState({})
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api(`/public/${tenantSlug}/${formSlug}`).then(setForm).catch((e) => setErr(e.message))
  }, [tenantSlug, formSlug])

  const visible = (f) => !f.visible_when || String(data[f.visible_when.key] ?? '') === String(f.visible_when.equals ?? '')

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setErrors({}); setBusy(true)
    try {
      await api(`/public/${tenantSlug}/${formSlug}/submit`, { method: 'POST', body: { data } })
      setDone(true); window.scrollTo(0, 0)
    } catch (e2) {
      setErr(e2.message)
      if (e2.fieldErrors) setErrors(e2.fieldErrors)
    } finally { setBusy(false) }
  }

  const uploadCtx = async (fd) => api(`/public/${tenantSlug}/${formSlug}/upload`, { method: 'POST', body: fd })

  return (
    <div className="login-wrap" style={{ justifyContent: 'flex-start', paddingTop: 30 }}>
      <img className="logo-big" style={{ width: 300 }} src="/logo.png" alt="Formobile" />
      <div className="pencil">فرم آنلاین</div>

      <div className="card" style={{ width: 'min(680px,96vw)', marginBottom: 30 }}>
        {err && <div className="err">{err}</div>}
        {done && <div className="ok">✓ پاسخ شما با موفقیت ثبت شد. سپاسگزاریم.</div>}
        {!form && !err && <div className="hint">در حال بارگذاری فرم…</div>}

        {form && !done && (
          <form onSubmit={submit}>
            <h2>{form.title}</h2>
            {form.description && <p className="sub">{form.description}</p>}
            {(form.schema.fields || []).filter(visible).map((f) => (
              <FieldInput key={f.key || f.id} field={f} value={data[f.key]}
                error={errors[f.key]} uploadCtx={uploadCtx}
                onChange={(v) => setData((d) => ({ ...d, [f.key]: v }))} />
            ))}
            <button className="btn block" disabled={busy}>{busy ? 'در حال ثبت…' : 'ثبت پاسخ'}</button>
          </form>
        )}
        {done && <button className="btn ghost block" onClick={() => { setDone(false); setData({}) }}>ثبت پاسخ جدید</button>}
      </div>

      <div className="footer-nav">
        <span>ساخته‌شده با Formobile</span><a href="/login">ورود اعضا</a>
      </div>
    </div>
  )
}
