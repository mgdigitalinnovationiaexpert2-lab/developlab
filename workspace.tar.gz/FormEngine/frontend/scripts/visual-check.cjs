// بررسی بصری خودکار: اسکرین‌شات صفحات اصلی + جمع‌آوری خطاهای کنسول
const { chromium } = require('playwright')
const fs = require('fs')

const BASE = 'http://127.0.0.1:8000'
const OUT = '../../design/screenshots'

async function shoot(page, name) {
  await page.waitForTimeout(700)
  await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: false })
  console.log('shot:', name)
}

;(async () => {
  fs.mkdirSync(OUT, { recursive: true })
  const browser = await chromium.launch({ args: ['--no-sandbox'] })
  const errors = []
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'fa-IR' })
  const page = await ctx.newPage()
  page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text()}`) })
  page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`))

  await page.goto(`${BASE}/login`, { waitUntil: 'networkidle' })
  await shoot(page, '01-login')

  await page.fill('input[autocomplete="username"]', 'farzad')
  await page.fill('input[autocomplete="current-password"]', 'farzad1234')
  await page.click('button.btn.block')
  await page.waitForURL(`${BASE}/`, { timeout: 15000 })
  await page.waitForSelector('table')
  await shoot(page, '02-workspace-farzad')

  // اشتراک‌گذاری مسیر
  await page.click('text=اشتراک‌گذاری مسیر')
  await page.waitForSelector('.modal')
  await shoot(page, '03-share-modal')
  await page.click('.modal button.btn.dark')

  // فرم‌ساز
  await page.click('table tbody tr:first-child a:has-text("ویرایش")')
  await page.waitForSelector('.builder')
  await page.click('.pitem:has-text("تاریخ شمسی")')
  await page.waitForTimeout(300)
  await shoot(page, '04-builder')

  // اعضا
  await page.goto(`${BASE}/members`, { waitUntil: 'networkidle' })
  await page.waitForSelector('table')
  await shoot(page, '05-members')

  // پاسخ‌ها
  await page.goto(`${BASE}/`, { waitUntil: 'networkidle' })
  await page.click('table tbody tr:first-child a:has-text("پاسخ‌ها")')
  await page.waitForSelector('table')
  await shoot(page, '06-responses')

  // گزارش رویدادها
  await page.goto(`${BASE}/audit`, { waitUntil: 'networkidle' })
  await shoot(page, '07-audit')

  // ورود به‌عنوان عضو دیگر → اثبات جداسازی
  const ctx2 = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'fa-IR' })
  const p2 = await ctx2.newPage()
  p2.on('pageerror', (e) => errors.push(`[pageerror2] ${e.message}`))
  await p2.goto(`${BASE}/login`, { waitUntil: 'networkidle' })
  await p2.fill('input[autocomplete="username"]', 'maryam')
  await p2.fill('input[autocomplete="current-password"]', 'maryam1234')
  await p2.click('button.btn.block')
  await p2.waitForURL(`${BASE}/`, { timeout: 15000 })
  await p2.waitForSelector('.side')
  await shoot(p2, '08-workspace-maryam')

  // فرم عمومی
  const ctx3 = await browser.newContext({ viewport: { width: 1100, height: 1000 }, locale: 'fa-IR' })
  const p3 = await ctx3.newPage()
  p3.on('pageerror', (e) => errors.push(`[pageerror3] ${e.message}`))
  await p3.goto(`${BASE}/f/farzadegan/paeiz`, { waitUntil: 'networkidle' })
  await p3.waitForSelector('form')
  await shoot(p3, '09-public-form')
  // اعتبارسنجی سمت سرور
  await p3.fill('#f-full_name', 'تست بصری')
  await p3.fill('#f-national_id', '123')
  await p3.click('button.btn.block')
  await p3.waitForTimeout(900)
  await shoot(p3, '10-public-validation')

  await browser.close()
  console.log(errors.length ? 'ERRORS:\n' + errors.join('\n') : 'no console/page errors ✓')
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
